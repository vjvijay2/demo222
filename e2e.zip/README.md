##项目框架文档##
alain | https://ng-alain.com/chart/getting-started/zh
ng-zorro | https://ng.ant.design/components/breadcrumb/zh

应 
  npm install | 安裝依賴

  npm start | 启动

  npm run build -pro | 打包

默认访问路劲 

http://localhost:4200 

对应目录 
├── _mock                                       # Mock 数据规则
├── src
│   ├── app
│   │   ├── core                                # 核心模块
│   │   │   ├── i18n
│   │   │   ├── net
│   │   │   │   └── default.interceptor.ts      # 默认HTTP拦截器
│   │   │   ├── services
│   │   │   │   └── startup.service.ts          # 初始化项目配置
│   │   │   └── core.module.ts                  # 核心模块文件
│   │   ├── layout                              # 通用布局
│   │   ├── routes
│   │   │   ├── **                              # 业务目录
│   │   │   ├── routes.module.ts                # 业务路由模块
│   │   │   └── routes-routing.module.ts        # 业务路由注册口
│   │   ├── shared                              # 共享模块
|   |   |   ├── untils                          # 公共方法文件
│   │   │   └── shared.module.ts                # 共享模块文件
│   │   ├── app.component.ts                    # 根组件
│   │   └── app.module.ts                       # 根模块
│   │   └── delon.module.ts                     # @delon模块导入
│   ├── assets                                  # 本地静态资源
│   ├── environments                            # 环境变量配置
│   ├── styles                                  # 样式目录
└── └── style.less                              # 样式引导入口

alain命令

ng g ng-alain:module sys | 新建模块 （手动添加路由）

ng g ng-alain:list list -m=sys | 新建页面（自动添加路由）

ng g ng-alain:view view -m=sys -t=list | 新建详情页

ng g ng-alain:empty name -m=sys -t=list | 新建空白页（自动添加路由）