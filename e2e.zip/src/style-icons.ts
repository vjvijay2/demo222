// Custom icon static resources

// import {
//   InfoOutline,
//   BulbOutline,
//   ProfileOutline,
//   ExceptionOutline,
//   LinkOutline,
//   FolderOutline,
//   FileZipOutline,
//   DesktopOutline,
//   FileProtectOutline,
//   FileTextOutline,
//   SolutionOutline,
//   ClockCircleOutline
// } from '@ant-design/icons-angular/icons';

// export const ICONS = [
//   InfoOutline,
//   BulbOutline,
//   ProfileOutline,
//   ExceptionOutline,
//   LinkOutline,
//   FolderOutline,
//   FileZipOutline,
//   DesktopOutline,
//   FileProtectOutline,
//   FileTextOutline,
//   SolutionOutline,
//   ClockCircleOutline
// ];
import * as Icons from '@ant-design/icons-angular/icons';
const iconList = [];
for (const key in Icons) {
  iconList.push(Icons[key]);
}
export const ICONS = iconList;