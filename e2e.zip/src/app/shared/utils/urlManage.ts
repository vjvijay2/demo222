export let iwxServiceUrl:string;
export let utilToolUrl:string;
((doc)=>{
    urlManage();
})(document)

 // 2022-7-12:ipocket.idpbgtn.efoxconn.com替換eisp.idpbgtn.efoxconn.com
function urlManage(){
    if (window.location.host=="lms.idpbgind.efoxconn.com"|| window.location.host == "10.208.193.124:8000") {
        iwxServiceUrl = "https://microservice.abgind.foxconn.com/india/gateway"
        utilToolUrl = "https://mshr.idpbgind.efoxconn.com/APIO/api2/N"
    }else if (window.location.host=="lms.idpbgtn.efoxconn.com"|| window.location.host == "10.208.193.124:8000") {
        iwxServiceUrl = "https://microservice.abgind.foxconn.com/india/gateway"
        utilToolUrl = "https://mshr.idpbgtn.efoxconn.com/APIO/api2/N"
    } else {
        iwxServiceUrl ="http://10.208.193.125:8086/gateway/manager";  //3:18
        utilToolUrl = "http://10.172.114.90:8484/api2/N"
    }
}