export function isNotDate(date) {
  const reg = /((^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(10|12|0?[13578])([-\/\._])(3[01]|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(11|0?[469])([-\/\._])(30|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(0?2)([-\/\._])(2[0-8]|1[0-9]|0?[1-9])$)|(^([2468][048]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([3579][26]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][13579][26])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][13579][26])([-\/\._])(0?2)([-\/\._])(29)$))/gi;
  if (!reg.test(date)) {
    return true;
  }
  return false;
}

/**
 * 日期转字符串
 *
 * @ export
 * @ param {*} date
 * @ returns
 */
export function dateToString(date) {
  // const date = stringToDate(date_string, "-");
  const year = date.getFullYear();
  let month = (date.getMonth() + 1).toString();
  let day = date.getDate().toString();
  if (month.length === 1) {
    month = "0" + month;
  }
  if (day.length === 1) {
    day = "0" + day;
  }
  const dateTime = year + "-" + month + "-" + day;
  return dateTime;
}

/**
 * 重新组合表单请求数据
 *
 * @ export
 * @ param {*} get
 * @ param {*} value
 */
export function assemblySFValue(get: any, value: any) {
  for (const key in value) {
    if (value.hasOwnProperty(key)) {
      // 判断是否是日期格式
      if (isNotDate(value[key].toString())) {
        get[key] = value[key];
      } else {
        // 包含
        const date = new Date(value[key]);
        get[key] = dateToString(date);
      }
    }
  }

  return get;
}

/**
 * 配置数据v值
 */
export function updateDataConfigChange(oldData: any, newData: any) {
  for (const key in oldData) {
    if (oldData.hasOwnProperty(key)) {
      oldData[key] = newData[key];
    }
  }
  return oldData;
}
