import * as CryptoJS from 'crypto-js';
/**
 * AES 加密
 * @param str 要加密的字符串
 * @param keyStr 加秘鑰（可選）默認 'abcdefghijklmnopqrstuvwxyz123456'
 * @param ivStr 偏移量（可選）默認 '0000000000000000'
 */
export function encrypt(str, keyStr?: any, ivStr?: any) {
    const key = keyStr ? CryptoJS.enc.Utf8.parse(keyStr) : CryptoJS.enc.Utf8.parse('abcdefghijklmnopqrstuvwxyz123456');
    const iv = ivStr ? CryptoJS.enc.Hex.parse(ivStr) : CryptoJS.enc.Hex.parse('0000000000000000');
    const encRes = CryptoJS.AES.encrypt(str, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    return encRes.toString();
}
/**
 * AES 解密
 * @param str 要解密的字符串
 * @param keyStr 解密鑰（可選）默認 'abcdefghijklmnopqrstuvwxyz123456'
 * @param ivStr 偏移量（可選）默認 '0000000000000000'
 */
export function decrypt(str, keyStr?: any, ivStr?: any) {
    const key = keyStr ? CryptoJS.enc.Utf8.parse(keyStr) : CryptoJS.enc.Utf8.parse('abcdefghijklmnopqrstuvwxyz123456');
    const iv = ivStr ? CryptoJS.enc.Hex.parse(ivStr) : CryptoJS.enc.Hex.parse('0000000000000000');
    const encRes = CryptoJS.AES.decrypt(str, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    return encRes.toString(CryptoJS.enc.Utf8);
}

export const security = {
    cfg: {
        iv: CryptoJS.enc.Hex.parse('0000000000000000'),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    },
    encryptForWeb(str) {
        const k = CryptoJS.enc.Utf8.parse("794fc586a5a5a589c4ac47402f7419c2");
        return CryptoJS.AES.encrypt(str, k, this.cfg).toString();
    },
    decryptForWeb(str) {
        const k = CryptoJS.enc.Utf8.parse("794fc586a5a5a589c4ac47402f7419c2");
        return CryptoJS.enc.Utf8.stringify(
            CryptoJS.AES.decrypt(str, k, this.cfg)
        );
    },
    encrypt(str, key) {
        const k = CryptoJS.enc.Utf8.parse(key);
        return CryptoJS.AES.encrypt(str, k, this.cfg).toString();
    },
    decrypt(str, key) {
        const k = CryptoJS.enc.Utf8.parse(key);
        return CryptoJS.enc.Utf8.stringify(CryptoJS.AES.decrypt(str, k, this.cfg));
    },
    md5(str) {
        return CryptoJS.MD5(str).toString().toUpperCase();
    },
    genVldCode(str, key) {
        return this.encrypt(this.md5(str + key), key)
    }
}

// JAVA加密
export function javaPostApi(param: any) {
    // console.log('param',param)
    const body = this.security.encryptForWeb(JSON.stringify(param.data));

    return new Promise((resolve, reject) => {
        this.http.post(param.url, body, null, {headers:{"Content-Type": "application/json;charset=UTF-8"}}).subscribe(data => {
          const res = JSON.parse(this.security.decryptForWeb(data));
          resolve(res);
        }, err => {// 请求错误
          reject(err);
        });
      }).catch(reason => {
        console.log(reason)
      })
}