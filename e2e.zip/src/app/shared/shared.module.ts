import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';

// delon
import { CacheService } from "@delon/cache";
import { AlainThemeModule, DrawerHelper, ModalHelper } from '@delon/theme';
import { DelonABCModule } from '@delon/abc';
import { DelonChartModule } from '@delon/chart';
import { DelonACLModule } from '@delon/acl';
import { DelonFormModule } from '@delon/form';
// i18n
import { TranslateModule } from '@ngx-translate/core';

// #region third libs
import { NgZorroAntdModule, NzMessageService, NzModalService } from 'ng-zorro-antd';
import { CountdownModule } from 'ngx-countdown';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { NgxImageGalleryModule } from 'ngx-image-gallery';

const THIRDMODULES = [
  NgZorroAntdModule,
  CountdownModule,
  DragDropModule,
  NgxImageGalleryModule,
];
// #endregion

// #region your componets & directives
import { PRO_SHARED_COMPONENTS } from '../layout/pro';
import { LangsComponent } from './components/langs/langs.component';
import { EditorComponent } from './components/editor/editor.component';
import { ImgComponent } from './components/img/img.component';
import { ImgDirective } from './components/img/img.directive';
import { DelayDirective } from './components/delay/delay.directive';
import { MasonryDirective } from './components/masonry/masonry.directive';
import { ScrollbarDirective } from './components/scrollbar/scrollbar.directive';
import { FileManagerComponent } from './components/file-manager/file-manager.component';
import { StatusLabelComponent } from './components/status-label/status-label.component';
import { MouseFocusDirective } from './components/mouse-focus/mouse-focus.directive';
import { QUICK_CHAT_COMPONENTS } from './components/quick-chat';
import { AddressComponent } from './components/address/address.component';
import { UploadPhotoComponent } from "./components/upload-photo/upload-photo.component";
import { MyCellComponent } from "./components/grid-cell/cell.component"
import { MyCellTableComponent } from "./components/grid-cell/cell-table.component"
import { MyCellGroupComponent } from "./components/grid-cell/cell-group.component"
import { WangEditorDemo } from "./components/wang-editor/wang-editor.component";
import { EditorOracleComponent } from './components/editor-oracle/editor.component';
import { UploadPhotoOracleComponent } from "./components/upload-photo-oracle/upload-photo.component";
// AES 加密
import * as CryptoJS from 'crypto-js';
import { AppAadharNumberComponent } from './components/aadhar-number/aadhar-number.component';


const COMPONENTS_ENTRY = [
  LangsComponent,
  ImgComponent,
  FileManagerComponent,
  StatusLabelComponent,
  AddressComponent,
  UploadPhotoComponent,
  MyCellComponent,
  MyCellTableComponent,
  MyCellGroupComponent,
  WangEditorDemo,
  UploadPhotoOracleComponent,
  ...QUICK_CHAT_COMPONENTS,
  AppAadharNumberComponent
];
const COMPONENTS = [
  EditorComponent,
  EditorOracleComponent,
  ...COMPONENTS_ENTRY,
  ...PRO_SHARED_COMPONENTS
];
const DIRECTIVES = [
  ImgDirective,
  DelayDirective,
  MasonryDirective,
  ScrollbarDirective,
  MouseFocusDirective,
];
// #endregion

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    AlainThemeModule.forChild(),
    DelonABCModule,
    DelonChartModule,
    DelonACLModule,
    DelonFormModule,
    // third libs
    ...THIRDMODULES,
  ],
  declarations: [
    // your components
    ...COMPONENTS,
    ...DIRECTIVES
  ],
  entryComponents: COMPONENTS_ENTRY,
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    AlainThemeModule,
    DelonABCModule,
    DelonChartModule,
    DelonACLModule,
    DelonFormModule,
    // i18n
    TranslateModule,
    // third libs
    ...THIRDMODULES,
    // your components
    ...COMPONENTS,
    ...DIRECTIVES,
  ],
})
export class SharedModule {
  constructor(
    public cacheService: CacheService,
    public msg: NzMessageService,
    public modalSvr: NzModalService,
    public router: Router,
    public activedRouter: ActivatedRoute,
    private drawerHelper: DrawerHelper,
    private modalHelper: ModalHelper
  ) { }
  /**
   * AES 加密
   * @param str 要加密的字符串
   * @param keyStr 加秘鑰（可選）默認 'abcdefghijklmnopqrstuvwxyz123456'
   * @param ivStr 偏移量（可選）默認 16個0
   */
  encrypt(str, keyStr?: any, ivStr?: any) {
    const key = keyStr ? CryptoJS.enc.Utf8.parse(keyStr) : CryptoJS.enc.Utf8.parse('abcdefghijklmnopqrstuvwxyz123456');
    const iv = ivStr ? CryptoJS.enc.Hex.parse(ivStr) : CryptoJS.enc.Hex.parse('0000000000000000');
    const encRes = CryptoJS.AES.encrypt(str, key, {
      iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    return encRes.toString();
  }
  /**
   * 彈出msg提示信息,當提示信息為loading類型時需手動關閉
   * params 
   * params.type: success/error/info/warning/loading
   * params.content: string | TemplateRef<void>
   * defaule: info
   */
  showMsg(type, cnt) {
    switch (type) {
      case 'success':
        this.msg.success(cnt);
        break;
      case 'error':
        this.msg.error(cnt);
        break;
      case 'warning':
        this.msg.warning(cnt);
        break;
      case 'loading':
        this.msg.loading(cnt, { nzDuration: 0 });
        break;
      default:
        this.msg.info(cnt.content);
        break;
    }
  }
  // 移除提示信息
  hideMsg() {
    this.msg.remove();
  }
  /**
   * url跳轉頁面
   * params 
   * params.url String
   * params.data JSONObject {}
   */
  linkByUrl(params) {
    const _data = params.data ? params.data : {};
    this.router.navigate([params.url], { queryParams: _data });
  }
  // 獲取URL攜帶的參數 異步返回
  getUrlData(callback) {
    this.activedRouter.queryParams.subscribe(res => {
      callback(res);
    });
  }
  /**
   * 設置緩存
   * params 
   * params.key String
   * params.data JSON Object
   */
  setCache(params) {
    this.cacheService.set(params.key, params.data, {
      type: 's'
    });
  }
  /**
   * 獲取數據緩存
   * key String 
   */
  getCache(key) {
    return this.cacheService.get(key, {
      mode: 'none'
    });
  }
  // 打開右側抽屜
  openDrawer(title, component, data,  callback?: any) {
    // console.log(data.isopen)
    this.drawerHelper.create(title, component, data, {
      size: "lg",
      drawerOptions: {
        nzWrapClassName: 'drawer-wrap',
        nzMaskClosable:data.isopen?false:true,
        nzClosable: true
      }
    }).subscribe(res => {
      if (callback) {
        callback(res);
      }
    });
  }
  // 打開彈框
  openMode(component, data, option?: any, callback?: any) {
    const _option = option ? option : {};
    this.modalHelper.create(component, data, _option).subscribe(res => {
      if (callback) {
        callback(res);
      }
    })
  }
}
