export interface IcellData{
    label:string
    value:string
    [key:string]:string
}