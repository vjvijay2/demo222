import { Component, Input, OnChanges, AfterViewInit, OnInit } from '@angular/core';
import { STColumn, STPage } from '@delon/abc';

@Component({
    selector: 'my-cell-table',
    template: `
    <div class="myCell_table_list">
       <div class="myCell_table_label">{{label}}:</div>
       <div class="myCell_table_value">
       <div class="global_table" *ngIf="source.length > 0 && isShow == true">
       <st #st [data]="source" [columns]="columns" [bordered]="true" [scroll]="{x: '100%'}" [widthMode]="{type: 'strict'}"
            [page]="pages">
        </st>
        </div>
       </div>
       <ng-content></ng-content>
    </div>
  `,
  styleUrls:["../index.less"],
    host: {
        class: 'my_cell_item'
    }
  
})
export class MyCellTableComponent implements OnInit, AfterViewInit {
  @Input()
  label:string;
  @Input()
  width:number = 100
  @Input()
  value:any;
    enum= [{ "value": "1", "label": "Review by" }, { "value": "2", "label": "Co-reviewed by" }, { "value": "2.5", "label": "Raised by" }, { "value": "3", "label": "Approval by" }]
    // 表头
    columns: STColumn[] = [];
    // 表数据
    source: any[] = [];
    // table 页码配置
    pages: STPage = {
        show: false,// 显示分页
        front: false, // 关闭前端分页，true是前端分页，false后端控制分页
        showSize: true
    };
    isShow=false
  constructor(){}
    // BadgeID: "H2410779"
    // Contact Form Type: 1
    // Email: "idpbg-it-wfweb@mail.foxconn.com"
    // Name: "許全順"
    // Signing Sequence: "1"
    // Signing Step: "1"
    // SigningTier: "2"
    // type: "Y"
    ngOnInit(): void {
        // console.log(this.label)
        if (this.label == "Approval by"){
           this.columns=[
               {"index":"Name","title":"Name"}
           ]
        }
        else {
            this.columns = [
                { "index": "Name","title":"Name" },
                { "index": "Signing Step", "title": "Signing Step" },
                { "index": "Signing Sequence", "title": "Signing Sequence" },
            ]
        }
        
        
       
       
    }
    ngAfterViewInit():void{
        this.changeLabelWidth(this.width)
        setTimeout(()=>{
            let value = this.enum.find(e => e.label == this.label).value
            if (this.value) {
                // console.log(this.value)
                if (this.value.findIndex(e => e.SigningTier == value) >= 0) {
                    this.isShow = true
                }
                this.value.map(item => {
                    if (item.SigningTier == value) {
                        this.source.push(item)
                    }
                })
            }
        },1000)    
    }
    changeLabelWidth = (wid:number):void=>{
        let dom = document.querySelector(".myCell_label") as HTMLElement
        dom.style.width = wid+"px"
    }
}
