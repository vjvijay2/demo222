import { Component, Input, OnChanges, AfterViewInit, OnInit } from '@angular/core';

@Component({
    selector: 'my-cell',
    template: `
    <div class="myCell_list">
       <div class="myCell_label">{{label}}:</div>
       <div class="myCell_value">{{value}}</div>
       <ng-content></ng-content>
    </div>
  `,
  styleUrls:["../index.less"],
    host: {
        class: 'my_cell_item'
    }
  
})
export class MyCellComponent implements OnInit, AfterViewInit {
  @Input()
  label:string;
  @Input()
  width:number;
  @Input()
  value:string;
  constructor(){}
    ngOnInit(): void {
       
    }
    ngAfterViewInit():void{
           if (this.width) {
               this.changeLabelWidth(this.width)
           }
    }
    changeLabelWidth = (wid:number):void=>{
        let dom = document.querySelector(".myCell_label") as HTMLElement
        dom.style.width = wid+"px"
    }
}
