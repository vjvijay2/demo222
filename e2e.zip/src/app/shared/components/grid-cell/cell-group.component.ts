import { Component, OnInit, Input } from '@angular/core'
import {IcellData} from "./types"
@Component({
   selector:"my-cell-group",
   template:`
    <div class="my_cell_group" *ngFor="let item of data">
      <my-cell class="my_cell_item" [(ngModel)]="item.value" [label]="item.label"></my-cell>
    </div>
   `
})

export class MyCellGroupComponent implements OnInit{
    @Input()
    data: IcellData[];
    constructor(){}
    ngOnInit():void{

    }
}