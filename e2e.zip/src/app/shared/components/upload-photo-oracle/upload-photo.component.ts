import { Component, OnInit} from '@angular/core';
import { NzMessageService, NzModalRef} from 'ng-zorro-antd';
import { SharedModule } from "@shared";
import { I18NService } from '@core/i18n/i18n.service';
import { _HttpClient } from '@delon/theme';

@Component({
  selector: 'app-upload-photo',
  templateUrl: './upload-photo.component.html',
  styleUrls: ['./upload-photo.component.less']
})
export class UploadPhotoOracleComponent implements OnInit {
  fileUrls = []; // 實时預覽图片地址
  uploading = false;
  disable = false;
  previewVisible = false; // 大图預覽
  previewImage = ""; // 大图預覽地址
  constructor(
    public msgSrv: NzMessageService,
    private shareSvr: SharedModule,
    private i18n: I18NService,
    private http: _HttpClient,
    private modal: NzModalRef,
  ) { }

  ngOnInit(): void {
  }
  
  // beforeUpload
  beforeUpload = (file,fileList) => {
    if (file.size > 500000) {
      let str = this.i18n.currentLang == "en-US" ? "Please select a picture less than 500KB" : "請選擇小於500kb的圖片";
      this.shareSvr.showMsg("error", this.i18n.fanyi(str));
      return false;
    }
    let imgType = file.type.indexOf('image/png') == -1 && file.type.indexOf('image/jpg') == -1 && file.type.indexOf('image/jpeg');
    if (imgType) {
      let str = this.i18n.currentLang == "en-US" ? "Please choose PNG or JPG format" : "請選擇PNG或JPG格式的圖片";
      this.shareSvr.showMsg("error", this.i18n.fanyi(str));
      return false;
    }
    this.fileUrls = fileList;
    return false;
  };
  getBase64(img: File, callback: (img: string) => void): void {
    const reader = new FileReader();
    reader.readAsDataURL(img);
    reader.addEventListener('load', () => callback(reader.result!.toString()));
  }
  handleUpload(){
    this.uploading = true;
    this.disable = true;  
    // console.log("fileUrls",this.fileUrls)
    let imgs=this.fileUrls;
    this.getBase64(imgs[0], (base64) => {
      let base64Str = encodeURIComponent(base64.split('base64,')[1]);
      if (base64Str == "undefined") {
        this.msgSrv.error(this.i18n.fanyi("upload.fail.tips"))
        // this.uploading = false;
        return
      }
     
  })
}
  // 展示大图
  showBigImg(url){
    this.previewImage = url;
    this.previewVisible = true;
  }
  // 刪除
  delete(id){
    this.fileUrls = this.fileUrls.filter(element => {
      return element.uid !== id;
    });
  }
  close() {
    this.modal.close();
  } 
}
