import { Component, OnInit, AfterViewInit, Input, OnChanges, Output, EventEmitter, SimpleChanges } from "@angular/core"
import E from "wangeditor";
// import E from "../../../../../node_modules/wangeditor/wangeditor"
import { NzMessageService } from 'ng-zorro-antd';
import { resolve } from 'q';
@Component({
    selector: 'wang-editor',
    templateUrl: './wang-editor.component.html',
    styleUrls: ["./wang-editor.component.less"]
})
export class WangEditorDemo implements OnInit, AfterViewInit, OnChanges {
    editor: any;
    @Input()
    editorId: any;
    @Input()
    content: any = ""
    @Input()
    picUrl: any = ""
    editorHtml: any
    @Output()
    getEditorContent = new EventEmitter<any>();
    imgBase64: any
    constructor(
        private msg: NzMessageService,
    ) { }
    ngOnInit = (): void => {

    }
    ngAfterViewInit() {
        this.create(this.editorId)
    }
    ngOnChanges(changes: SimpleChanges): void {
        // if (this.editorId == 'QstContent') {
        //     let idx = this.editorId == 'QstContent' ? -1 : this.editorId.replace(/QstOption/, "");
        //     this.asyncReviewData(idx).then(res => {
        //         if (res) {
        //             this.renderD()
        //         }
        //     })
        // }
    }
    create(id) {
        const editor = new E("#" + id);
        editor.config.height = this.editorId == 'QstContent' ? 100 : 50;
        editor.config.zIndex = 0;
        editor.config.showMenuTooltips = false;  //隐藏菜单栏提示
        editor.config.uploadImgShowBase64 = true;
        editor.config.uploadImgAccept = ["jpg", "jpeg", "png"];
        editor.config.uploadImgMaxSize = 1.5 * 1024 * 1024; // 1.5M
        editor.config.uploadImgMaxLength = 1; // 一次最多上传 1 个图片
        editor.config.showLinkImg = false; // 隐藏插入网络图片的功能 
        editor.config.showFullScreen = false;
        editor.config.pasteFilterStyle = false;  //關閉粘貼樣式的過濾
        // editor.config.showLinkImgAlt = false;  // 配置alt选项      
        // editor.config.showLinkImgHref = false;  // 配置超链接
        // 配置菜单栏，删减菜单
        editor.config.menus = ['head',
            'bold',
            'fontSize',
            'fontName',
            'italic',
            'underline',
            'strikeThrough',
            'indent',
            'lineHeight',
            'foreColor',
            'backColor',
            'link',
            'list',
            'todo',
            'justify',
            'quote',
            'emoticon',
            'table',
            'splitLine',
            'undo',
            'redo',];

        // 配置粘貼文本的內容處理
        // editor.config.pasteTextHandle = function (pasteStr) {
        //     console.log('粘貼內容', pasteStr)
        //     let editorHtml1
        //     if (pasteStr) {
        //         let startStr = pasteStr.indexOf("<!--[if-->")
        //         let endStr = pasteStr.indexOf("<!--[endif]-->") + 14
        //         console.log('開始', startStr, "結束", endStr)
        //         if (startStr != 0) {
        //             editorHtml1 = pasteStr.slice(0, startStr) + pasteStr.slice(endStr, pasteStr.length);
        //             console.log('處理後的結果', pasteStr)
        //         }

        //     }
        //     return editorHtml1
        // }
        editor.config.onfocus = () => {
            // console.log(this.editorId)
        }
        editor.config.onchange = newHtml => {
            // console.log(newHtml);
            this.editorHtml = newHtml;
            // let len = newHtml.indexOf('<img');
            // let idx = id == 'QstContent' ? -1 : id.replace(/QstOption/, "");
            this.getEditorContent.emit(newHtml)

        };
        // 自定义图片上传
        editor.config.customUploadImg = function (resultFiles, insertImgFn) {
            // resultFiles 是 input 中选中的文件列表
            // console.log(resultFiles);
            if (this.editorHtml.indexOf('<img') == -1) {
                this.getBase64(resultFiles[0]).then(res => {
                    this.imgBase64 = res;
                    // insertImgFn 是获取图片 url 后，插入到编辑器的方法
                    insertImgFn(res);
                });
            } else {
                this.msg.error("只能上传一张图片");
            }
        };
        // 创建编辑器       
        editor.create();
        this.editor = editor;

        // this.renderD()

    }
    renderD() {
        // 回显
        if (this.content) {
            let str = this.picUrl ? this.content.replace(/src=""/, `src="${this.picUrl}"`) : this.content;
            this.editor.txt.html(str);
        }

    }
    asyncReviewData(id) {
        return new Promise((resolve, reject) => {
            if (id) {
                resolve(id)
            }
        })
    }
    getEditorData() {
        // 通过代码获取编辑器内容
        let data = this.editor.txt.html();
        let text = this.editor.txt.text();
        // 在光标位置插入文字 editor.cmd.do('insertHTML', '<p>...</p>')
        // 在光标位置插入图片 editor.cmd.do('insertImage', imgUrl)
    }
    // 清空编辑器内容
    clearEditor() {
        this.editor.txt.clear();
    }
    getBase64(file) {
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            let fileResult: any;
            reader.readAsDataURL(file);
            //开始转
            reader.onload = function () {
                fileResult = reader.result;
            };
            //失败
            reader.onerror = function (error) {
                reject(error);
            };
            //结束
            reader.onloadend = function () {
                resolve(fileResult);
            };
        });
    }

}