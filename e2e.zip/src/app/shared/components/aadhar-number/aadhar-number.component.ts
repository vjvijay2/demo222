import { Component, OnInit,Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { UploadFile, NzMessageService } from 'ng-zorro-antd';
// import { RecruitService } from "../../_net/recruit.service"
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';


@Component({
  selector: 'system-aadhar-number',
  templateUrl: './aadhar-number.component.html',
  // styleUrls: ['./aadhar-number.component.less']
  providers: [
    {
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => AppAadharNumberComponent),
        multi: true
    }
]

})
export class AppAadharNumberComponent implements OnInit, ControlValueAccessor {

  constructor(
    // private apiSvr: RecruitService,
    private msg: NzMessageService
  ) { }
// @Output() sonEvent = new EventEmitter()

@Input() sfValue: any
  AadharNumber: any
  inputValue: any
  isVisible: boolean = false
  fileList: UploadFile[] = []; // 文件列表集合
  title: string ="";
  fileName: string
  allData = [];

  ngOnInit() {
    this.title="Batch Import "+this.sfValue
    switch (this.sfValue) {
      case "AadharNumber":
        this.allData=[{ AadharNo: '' }]
        break;
      case "EmpId":
        this.allData=[{ 'Emp.ID': '' }]
        break;
    
      default:
        break;
    }
  }

  beforeUpload = (file: UploadFile): boolean => {
    this.fileName = file.name;
    this.fileList = [file]; // 此处可设置为添加数组
    return false;
}

  addFile(){
  }




  // 打開模態框
  openModel() {
    this.fileName = ""
    this.isVisible = true
  }

  // 模態框取消
  cancel() {
    this.isVisible = false
  }

  // 模態框確認
  ok() {
    //檢查是否有選擇文件
    if (this.fileList.length == 0) {
      this.msg.error("please select the file first");
      return;
    }

    this.fileList.forEach(file => {
      this.getFileData(file, (data) => {
        const wb: XLSX.WorkBook = XLSX.read(data, { type: 'binary' });
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        let json = XLSX.utils.sheet_to_json(ws, { defval: '' });

        //驗證是否有輸入工號
        if (json.length <= 0) {
          this.msg.error("No data found in excel.");
          return;
        }
        else if (Object.keys(json[0]).length != 1) {
          this.msg.error("Please download the correct template");//模板錯誤
          return;
        }
        // else if (Object.keys(json[0])[0] != 'AadharNo') {
        //   this.msg.error("Please download the correct template");//模板錯誤
        //   return;
        // }

        if(this.sfValue=="AadharNumber"){
          if(Object.keys(json[0])[0] != 'AadharNo'){
            this.msg.error("Please download the correct template");//模板錯誤
              return;
          }
        }else if(this.sfValue=="EmpId"){
          if(Object.keys(json[0])[0] != 'Emp.ID'){
            this.msg.error("Please download the correct template");//模板錯誤
              return;
          }
        }


        let AadharNo = "";
        json.map(item => {
          // AadharNo += item["AadharNo"] + ',';
          if(this.sfValue=="AadharNumber"){
            AadharNo += item["AadharNo"] + ',';
          }else if(this.sfValue=="EmpId"){
            AadharNo += item["Emp.ID"] + ',';
          }
        });


        if (AadharNo.length > 0) {
          this.inputValue = AadharNo.substring(0, AadharNo.length - 1);
        }
        else {
          this.inputValue = "";
        }

        // this.AadharNumber=this.AadharNumberValue
        this.propagateChange(this.inputValue);//將數據返回給ngModel返回的值

        // this.sonEvent.emit(this.AadharNumberValue)
        this.isVisible = false;
      });
    });

  }
  // 獲取Excel的數據
  getFileData(file, callback: (fle: string) => void): void {
    const reader = new FileReader();
    reader.readAsBinaryString(file);
    reader.addEventListener('load', () => callback(reader.result!.toString()));
  }
  // 下載模板
  getTemplate() {
    // let allData = [];
    // allData.push({ AadharNo: '' });
    this.exportHandle(this.allData);

  }
  exportHandle(data) {
    // this.exportLoading = true;
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer);
  }
  saveAsExcelFile(buffer: any) {
    const data: Blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
    });
    FileSaver.saveAs(data, new Date().getTime() + '.xlsx');
  }

  //文本框輸入時將數據傳入父控件
  modelChange($event){
    this.propagateChange(this.inputValue);
}

propagateChange = (_: any) => { };

/**将数据从模型传输到视图 */
writeValue(obj: any): void {
    if(this.inputValue===obj){
        return;
    }
    this.inputValue = obj;
}

/**将数据从视图传播到模型 */
registerOnChange(fn: any): void {
    /**fn其实是一个函数，当视图中的数据改变时就会调用fn指向的这个函数，从而达到将数据传播到模型的目的 */
    this.propagateChange = fn;  // 将fn的指向赋值给this.propagateChange，在需要将改变的数据传到模型时只需要调用this.propagateChange方法即可
}

registerOnTouched(fn: any): void {

}

setDisabledState?(isDisabled: boolean): void {

}
}
