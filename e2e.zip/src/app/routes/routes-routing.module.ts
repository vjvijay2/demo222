
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { environment } from "@env/environment";
// layout
import { LayoutProComponent } from "@brand";
import { LayoutPassportComponent } from "../layout/passport/passport.component";
// dashboard pages
// single pages
import { CallbackComponent } from "./callback/callback.component";
const routes: Routes = [
  {
    path: "",
    component: LayoutProComponent,
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      // Exception
      {
        path: "exception",
        loadChildren: () => import('./exception/exception.module').then(m => m.ExceptionModule)
      },
      // Template
      {
        path: "template",
        loadChildren: () => import("./template/template.module").then(m => m.TemplateModule)
      },
     //LMS
    

     {
      path:'Usermanage',
      loadChildren:()=>import('./LMS/user-management/user-management.module').then(m=>m.UserManagementModule)
     },
    
    ]
  },
  // passport
  {
    path: "passport",
    component: LayoutPassportComponent,
    children: [
      { path: "", loadChildren: () => import('./passport/passport.module').then(m => m.PassportModule) }
    ]
  },
  // 单页不包裹Layout
  { path: "callback/:type", component: CallbackComponent },
  { path: "**", redirectTo: "exception/404" }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: environment.useHash,
      // NOTICE: If you use `reuse-tab` component and turn on keepingScroll you can set to `disabled`
      // Pls refer to https://ng-alain.com/components/reuse-tab
      scrollPositionRestoration: "top",
      onSameUrlNavigation: 'reload'
    })
  ],
  exports: [RouterModule]
})
export class RouteRoutingModule { }
