import { NgModule } from '@angular/core';
import { SharedModule } from '@shared';
import { PassportRoutingModule } from './passport.routing.module';
import { UserLoginComponent } from './login/login.component';
import { UserRegisterComponent } from './register/register.component';
import { UserRegisterResultComponent } from './register-result/register-result.component';
import { UserLockComponent } from './lock/lock.component';
import { CookieService } from 'ngx-cookie-service'; 


const COMPONENTS = [
    UserLoginComponent,
    UserRegisterComponent,
    UserRegisterResultComponent,
    UserLockComponent
];
const COMPONENTS_NOROUNT = [];

@NgModule({
  imports: [
    SharedModule,
    PassportRoutingModule
  ],
  declarations: [
    ...COMPONENTS,
    ...COMPONENTS_NOROUNT
  ],
  providers:[CookieService],
  entryComponents: COMPONENTS_NOROUNT
})
export class PassportModule { }
