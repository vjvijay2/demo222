import { Component, OnInit, ViewChild } from '@angular/core';
import { NzDrawerRef, NzMessageService } from "ng-zorro-antd";
import { SFSchema, SFUISchema, SFComponent } from '@delon/form';

import { TemplateService } from "../../_net/template.service";
import { I18NService } from '@core/i18n/i18n.service';


@Component({
  selector: 'app-template-draw-add-draw',
  templateUrl: './add-draw.component.html',
})
export class TemplateDrawAddDrawComponent implements OnInit {
  record: any = {};

  @ViewChild("sf", { static: false }) sf: SFComponent;
  sfSchema: SFSchema;
  ui: SFUISchema = {
    '*': {
      spanLabelFixed: 100,
      grid: { span: 12 },
    },
    $no: {
      widget: 'text'
    },
    $href: {
      widget: 'string',
    },
    $description: {
      widget: 'textarea',
      grid: { span: 24 },
    },
  };
  constructor(
    private ref: NzDrawerRef,
    private msgSrv: NzMessageService,
    public apiSrv: TemplateService,
    private i18n: I18NService
  ) { }

  ngOnInit(): void {
    const _questionForm = [
      {
        key: "subjectDesc", name: "試題題幹", type: "textarea", ui: {
          grid: { span: 24 }
        }, required: "1"
      },
      { key: "isNecessary", name: "是否必答", type: "radio", enum: [{ label: "是", value: "1" }, { label: "否", value: "0" }], width: "100%", required: "1" },
      { key: "score", name: "分值", type: "number", required: "1" }
    ];
    this.sfSchema = this.apiSrv.jointSchema(_questionForm, this.record);
  }

  ok() {
    if(!this.sf.valid){
      this.msgSrv.error(this.i18n.fanyi('message.form.validate.undone'));
      return;
    }

    this.msgSrv.success("新增成功");  
  }

  cancel() {
    this.ref.close();
  }
}
