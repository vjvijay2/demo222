import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { _HttpClient } from "@delon/theme";
import { deepMerge } from "@delon/util";
import { Base64 } from "js-base64";

@Injectable()
export class TemplateService {
    constructor(
        private http: _HttpClient
    ) { }

    // post
    commonPostApi(param: any): Observable<any> {
        return this.http.post(param.url, param.data);
    }
    // get
    commonGetApi(param: any): Observable<any> {
        return this.http.get(param.url, param.data);
    }
    // downFile - post
    commonPostDownFile(param: any) {
        this.http.post(
            param.url,
            param.data, null, {
                responseType: "blob",
                observe: 'response'
            }
        ).subscribe(res => {
            this.downFileFun(res);
        });
    }
    // downFile - get
    commonGetDownFile(param: any) {
        this.http.get(
            param.url,
            param.data, {
                responseType: "blob",
                observe: 'response'
            }
        ).subscribe(res => {
            this.downFileFun(res);
        })
    }
    // 下載文件流附件方法
    downFileFun(res) {
        const fileName = res.headers.get("content-disposition").split("fileName=")[1];
        const objectUrl = URL.createObjectURL(res.body);
        const a = document.createElement("a");
        document.body.appendChild(a);
        a.style.display = "none";
        a.href = objectUrl;
        a.download = Base64.decode(fileName);
        a.click();
        document.body.removeChild(a);
    }
    // 獲取下拉選項
    getClassData(params: any): Observable<any> {
        return this.http.post(params.url, params.data).pipe(
            map((resp: any) => {
                const _data = [];
                resp.data.forEach(element => {
                    const _item = {
                        label: element[params.label],
                        value: element[params.value]
                    };
                    _data.push(_item);
                });
                return resp.data;
            }),
        )
    }
    // 表單初始化
    jointSchema(data, res?: any) {
        const _res = res ? res : {};
        const sfSchema = {
            properties: {},
            required: []
        };
        data.forEach(element => {
            const key = {};
            let _default = _res[element.key] || _res[element.key] === 0 ? _res[element.key] : element.default || element.default === 0 ? element.default : null;
            if (_default && element.multiple && element.multiple === '1') {
                _default = _default.split(",");
            }
            let selectWidth = element.width ? element.width : 230;
            if (typeof (selectWidth) === "string") {
                if (selectWidth.indexOf("%") === -1) {
                    selectWidth = selectWidth + "px";
                }
            }
            
            // 必填項
            if (element.required && element.required === "1") {
                sfSchema.required.push(element.key);
            }

            switch (element.type) {
                case "textarea":
                    
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        ui: {
                            widget: 'textarea',
                            autosize: {
                                minRows: element.minRows ? element.minRows : 3,
                                maxRows: element.maxRows ? element.maxRows : 6
                            },
                        },
                        default: _default
                    };
                    if (element.maxLength) {
                        key[element.key].maxLength = element.maxLength;
                    }
                    break;
                case "select":
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        ui: {
                            widget: 'select',
                            allowClear: true,
                            width: selectWidth,
                            placeholder: '请选择',
                            mode: element.multiple && element.multiple === '1' ? "tags" : "default",
                        },
                        default: _default
                    };
                    if (element.async) {
                        key[element.key].ui.asyncData = () => this.getClassData(element.async).pipe(map(
                            (value: any) => {
                                const _value = value;
                                if (element.showCode && element.showCode === "1") {
                                    _value.forEach(item => {
                                        item.label = item.label + "(" + item.value + ")";
                                    })
                                }
                                return _value;
                            }
                        ))
                    } else {
                        key[element.key].enum = element.enum;
                    }
                    break;
                case "date":
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        format: element.format ? element.format : "YYYY/MM/DD",
                        ui: {
                            widget: 'date',
                            displayFormat: element.format ? element.format : "YYYY/MM/DD",
                            format: element.format ? element.format : "YYYY/MM/DD"
                        },
                        default: _default
                    };
                    break;
                case "radio":
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        enum: element.enum,
                        ui: {
                            widget: "radio",
                        },
                        default: _default
                    };
                    break;
                case "checkbox":
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        ui: {
                            widget: "checkbox",
                        },
                        default: _default
                    };
                    if (element.async) {
                        key[element.key].ui.asyncData = () => this.getClassData(element.async).pipe(map(
                            (value: any) => {
                                const _value = value;
                                if (element.showCode && element.showCode === "1") {
                                    _value.forEach(item => {
                                        item.label = item.label + "(" + item.value + ")";
                                    })
                                }
                                return _value;
                            }
                        ))
                    } else {
                        key[element.key].enum = element.enum;
                    }
                    break;
                case "number": // 默認最小為 0 
                    key[element.key] = {
                        type: "number",
                        title: element.name,
                        default: _default,
                        minimum: element.minimum ? element.minimum : 0
                    };
                    if (element.maximum) {
                        key[element.key].maximum = element.maximum;
                    }
                    if (element.multipleOf) {
                        key[element.key].multipleOf = element.multipleOf;
                    }
                    break;
                case "custom":
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        ui: {
                            widget: "custom"
                        },
                        default: _default
                    };
                    break;
                default:
                    key[element.key] = {
                        type: "string",
                        title: element.name,
                        default: _default
                    };
                    if (element.maxLength) {
                        key[element.key].maxLength = element.maxLength;
                    }
                    if (element.pattern) {
                        key[element.key].pattern = element.pattern;
                    }
                    break;
            }
            if (element.description) {
                key[element.key].description = element.description;
            }
            if (element.readOnly && element.readOnly === "1") {
                key[element.key].readOnly = true;
            }
            if (element.ui) {
                key[element.key].ui = key[element.key].ui ? deepMerge(key[element.key].ui, element.ui) : element.ui;
            }
            sfSchema.properties = { ...sfSchema.properties, ...key };
        });
        return sfSchema;
    }
}