import { NgModule } from '@angular/core';
import { SharedModule } from '@shared';
import { TemplateRoutingModule } from './template-routing.module';
import { TemplateService } from "./_net/template.service";
import { TemplateListComponent } from './list/list.component';
import { TemplateDrawAddDrawComponent } from './draw/add-draw/add-draw.component';

const COMPONENTS = [
  TemplateListComponent];
const COMPONENTS_NOROUNT = [
  TemplateDrawAddDrawComponent];
const SERVICES = [TemplateService];
@NgModule({
  imports: [
    SharedModule,
    TemplateRoutingModule
  ],
  declarations: [
    ...COMPONENTS,
    ...COMPONENTS_NOROUNT
  ],
  entryComponents: COMPONENTS_NOROUNT,
  providers: [...SERVICES]
})
export class TemplateModule { }
