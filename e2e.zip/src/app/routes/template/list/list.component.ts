import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import {  STColumn, STChange, STPage } from "@delon/abc";
import { SFComponent, SFSchema } from "@delon/form";
import { deepMerge } from "@delon/util";

import { SharedModule } from "@shared";
import { TemplateService } from "../_net/template.service";
import { TemplateDrawAddDrawComponent } from "../draw/add-draw/add-draw.component";

@Component({
  selector: 'app-template-list',
  templateUrl: './list.component.html',
})
export class TemplateListComponent implements OnInit, AfterViewInit {
  @ViewChild('sf', { static: false }) st: SFComponent;
  constructor(
    private apiSvr: TemplateService,
    private shareSvr: SharedModule
  ) { }

  title: any = "模版示例";
  // 搜索表单
  sfSchema: SFSchema;
  // 表头
  columns: STColumn[] = [
    { title: "", type: 'checkbox', fixed: "left", width: '50px', className: "text-center" },
    { title: "ITEM", index: "item", className: "text-center" },
    { title: "題幹描述", index: "subjectDesc" },
    { title: "題目類型", index: "testType" },
    { title: "是否必答", index: "isNecessary" },
    { title: "分數", index: "score", className: "text-right" },
    { title: "創建人", index: "createBy" },
    { title: "創建時間", index: "createDt", width: '120px', type: "date"}
  ];
  // 表数据
  source: any[] = [];
  // 表格加載狀態
  loading = true;
  // 當前頁碼
  pi = 1;
  // 每頁數量
  ps = 10;
  // 當前總數量
  total = 0;
  // table 页码配置
  pages: STPage = {
    total: true,// 分页显示多少条数据
    show: true,// 显示分页
    front: false, // 关闭前端分页，true是前端分页，false后端控制分页
    showSize: true
  };
  // 選擇的數據集合
  checkedTableData = [];

  ngOnInit() {
    const _searchForm = [
      { key: "subjectDesc", name: "題幹描述", type: "text" }
    ];
    this.sfSchema = this.apiSvr.jointSchema(_searchForm);
  }
  ngAfterViewInit() {
    this.search();
  }
  // 搜索
  search(first?: any) {
    if(first){ this.pi = 1; }
    this.loading = true;
    setTimeout(() => {
      this.loading = false;
      this.total = 1;
      this.source = [
        {item: 1, subjectDesc: "描述", testType: "題型", isNecessary: "是", score: 30, createBy: "admin", createDt: "2020/06/01 17:11" }
      ]; 
    }, 2000);
  }
  // 新增
  insertData() {
    this.shareSvr.openDrawer("新增", TemplateDrawAddDrawComponent, {}, res => {
      if(res){
        this.search(true);
      }
    })
  }
  // 編輯
  editData() {}
  // 刪除
  delData() {
    
    this.shareSvr.modalSvr.confirm({
      nzTitle: "提示",
      nzContent: "確定要刪除選中的數據嗎?",
      nzOnOk: () => {
        // 填寫邏輯代碼
        this.shareSvr.showMsg("success", "刪除成功！");
      }
    })
  }
  // 切換分頁
  change(ret: STChange) {
    if (ret.type === "checkbox") {
      this.checkedTableData = ret.checkbox;
    }
    if (ret.type === 'pi') { // 页码变化
      this.pi = ret.pi
      this.search();
    }
    if (ret.type === 'ps') { // 每頁行數變化
      this.ps = ret.ps;
      this.search();
    }
  }
}
