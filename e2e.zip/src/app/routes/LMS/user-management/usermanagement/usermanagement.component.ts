import { Component, OnInit, ViewChild,ChangeDetectorRef } from '@angular/core';
import { SFComponent, SFSchema } from "@delon/form";
import { STColumn, STComponent, STChange, STPage, STData, } from "@delon/abc";
import { SettingsService } from '@delon/theme';
import { deepMerge } from "@delon/util";
import { NzMessageService, NzModalService } from "ng-zorro-antd";
import { SharedModule } from "@shared";
import { ActivatedRoute } from "@angular/router";
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { DatePipe } from "@angular/common";
import { I18NService } from '@core/i18n/i18n.service';
import { PublicNetService } from "../../../a_Public_net/Public_net.service";

import { UserManageAddComponent } from '../Drawer/user-manage-add/user-manage-add.component';


@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.less']
})
export class UsermanagementComponent implements OnInit {

  @ViewChild("sf", { static: false }) sf: SFComponent;
  // @ViewChild('st', { static: false }) private st!: STComponent;
  @ViewChild('st', { static: false }) private st: STComponent;


  constructor(
    private publicSvr: PublicNetService,
    public settings: SettingsService,
    private msgSvr: NzMessageService,
    private shareSvr: SharedModule,
    private modelSvr: NzModalService,
    private router: ActivatedRoute,
    private i18n: I18NService,
    private cdRef:ChangeDetectorRef
  ) { }
    SiteList: any;
  title:any = "User Manage";
  // 搜索表单
  sfSchema: SFSchema;
  source: any[] = []
  // 表格加載狀態
  loading = false;
  // 當前頁碼
  pi = 1;
  // 每頁數量
  ps = 10;
  // 當前總數量
  total = 0;
  Systemtype:any;
  // table 页码配置
  pages: STPage = {
    show: true,// 显示分页
    front: false, // 关闭前端分页，true是前端分页，false后端控制分页
    showSize: true,
    // pageSizes: [50, 100, 150, 200]
  };
  factoryId:any;
  factoryList=[];
  empid:any
  dept:any
  deptlist=[]
  checkedTableData = [];
  exportLoading: boolean = false;
  delIdx = 0;

  // 表頭
  columns: STColumn[] = [
    { title: "", type: "checkbox", fixed: "left", width: '50px', className: "text-center" },
    { title: "Item", index: "Rn", className: "text-center", width: "80px" },
    { title: "Emp Number", index: "EmpId", className: "text-center", width: "180px" },
    { title: "Emp Name", index: "EmpName", className: "text-center", width: "180px" },
    { title: "Department", index: "Dept", className: "text-center", width: "180px" },
   // { title: "Sytem Type", index: "SystemType", className: "text-center", width: "180px" },
    { title: "Site", index: "SiteName", className: "text-center", width: "180px" },
    { title: "Is Admin", index: "IsAdiminName", className: "text-center", width: "180px" },
    { title: "Extension No", index: "ExtNo", className: "text-center", width: "180px" },
  
    { title: "Create By", index: "AddBy", className: "text-center", width: "180px" },
    { title: "Create Date", index: "CreateDate", className: "text-center", width: "180px" },
   
    { title: "Edit By", index: "EditBy", className: "text-center", width: "180px" },
    { title: "Edit Date", index: "LastEditDate", className: "text-center", width: "180px" },
  ]

  private submit(i: STData): void {
    // this.msgSvr.success(JSON.stringify(this.st.pureItem(i)));
    this.updateEdit(i, false);
  }

  private updateEdit(i: STData, edit: boolean): void {
    i["edit"] = edit;
    // this.st.setRow(0, { price: 100000000 })
  }

  setRowData(index: number, name: string) {

  }

  ngOnInit() {

    this.createForm();
     setTimeout(() => {
    this.search(true);
   }, 100);
  }

  createForm(){
    const _form = [
      { key: "Factory", name: "Site", type: "custom" },
      { key: "EmpId", name: "Employee Id", type: "text" },
      { key: "Department", name: "Department", type: "custom" },
    ]
    this.sfSchema = this.publicSvr.jointSchema(_form);
    this.getUserInfo();
    // this.publicSvr.getselectSiteData().subscribe((res: any) => {
    //   this.factoryList = res;
    // })
    this.publicSvr
    .getGuardPassCode("Department")
    .subscribe((res: any) => {
      // console.log(res)
      //this. deptlist = res;
      this.deptlist = [{ label: "All", value: 'All' }, ...res];
    
   });
  }
  

  search(first?: any) {
    this.checkedTableData=[];
    if (first) {
      this.pi = 1;
    }
    this.loading = true;
    this.searchHandle()
  }

  searchHandle(isExport?: any) {
    const params = {
      Dept  :this.dept ? this.dept :'',
   AdminId  :this.publicSvr.getSettingUserInfo().eeid,
  Site  : this.factoryId ? this.factoryId :'',
      StartPage : isExport ? 1 : this.pi,
      PageSize : isExport ? '999999999999' : this.ps,////pagesize = 0的時候是查詢的全部的數據,可以用作導出
      Func: "SystemSettings-Get_User_manage"
    }
    console.log(this.sf)

    const _params = deepMerge(params, this.sf.value ? this.sf.value : {});
console.log(_params)
    this.publicSvr.iwxPost(_params, {
      headers: {
        apiID: "ffff-1740459507956-10208193125-1431",
        userKey: this.publicSvr.USER_TN
      }
    }, true).then((res: any) => {
      this.loading = false;
     console.log(res)
      this.exportLoading = false;
      if (res.IsOK == "1") {
        if (isExport) {
          let allData=[];
          if(res.List.length>0){
            let list=res.List;
            list.forEach((item)=>{
              allData.push({
                "Item":item.Rn,
                EmpId:item.EmpId,
                EmpName:item.EmpName,
                Site:item.SiteName,
                Dept:item.Dept,
                ExtNo:item.ExtNo,
                IsAdmin:item.IsAdiminName,
                Addby:item.AddBy,
                AddDate:item.CreateDate,
                EditBy:item.EditBy,
                EditDate:item.LastEditDate
              })
            })

            this.publicSvr.exportHandle(allData,11,"Users"+new Date().getTime()+".xlsx");
          }else{
            this.msgSvr.error("No Data!")
          }
        } else {
          this.source = res.List
        //   .map((item) => {
        //     const sitename = this.factoryList.find((value) => value.value == item.Site);
        //     return {
        //         ...item, // Spread the properties of the original item
        //         Site: sitename.label ? sitename.label : '', // Update the Site property
        //     };
        // });
        
          this.total = res.List && res.List.length > 0 ? res.List[0].Rowscount : 0;
         // this.source = res.List;
        }
      } else {
        if (!isExport) {
          this.source = [];
        }
        this.msgSvr.error(res.Msg);
      }
    })
  }

  getUserInfo() {
    const params = {
      Dept: '',
      EmpId: this.publicSvr.getSettingUserInfo().eeid,
      Site: '',
      StartPage: 1,
      PageSize: 999999999999,
      Func: "SystemSettings-Get_User_manage"
    };

    this.publicSvr.iwxPost(params, {
      headers: {
        apiID: "ffff-1740459507956-10208193125-1431",
        userKey: this.publicSvr.USER_TN
      }
    }, true).then((res: any) => {
      if (res.IsOK == "1") {
        console.log(res);
        const findadminanddri = res.List.some(item => item.IsAdiminName === 'Admin' || item.IsAdiminName === 'DRI');
// this.SiteList = res.List.map(item => {item.SiteId = item.SiteId ? item.SiteId : '';
//   item.SiteName = item.SiteName ? item.SiteName : '';
//       }).filter(item => item.SiteId !== '' && item.SiteName !== '');
// console.log(this.SiteList);
 res.List.forEach((element) => {
              if (!element) return;
              let _item: any = {};
              _item = {
                label: element.SiteName,
                value: element.SiteId,
                // repairitemgrupid :element.GroupIds,
                // repaircategorygrupid :element.GroupIds2
              };
              this.factoryList.push(_item);
            });
              if (this.factoryList.length > 0) {
    this.factoryId = this.factoryList[0].value; // default to first item
  }
    }});
  }

  








  add() {
    this.openDrawer("Add")
  }

  update() {
    if (this.checkedTableData.length !== 1) {
      this.shareSvr.showMsg("error", this.i18n.fanyi('table.content.edit-data-select'));
      return;
    }
    this.openDrawer("Edit")

  }

  openDrawer(name) {
    this.shareSvr.openDrawer(name, UserManageAddComponent, {
      option: name,
      editData:this.checkedTableData[0],
    }, res => {
      if (res) {
        // 新增成功刷新列表
        this.createForm();
        this.search(true);

      }
    });
  }

  delete() {
    if (this.checkedTableData.length == 0) {
      this.shareSvr.showMsg(
        "error",
        this.i18n.fanyi("table.content.edit-data-select")
      );
      return;
    }

    this.delIdx = 0;
    this.shareSvr.modalSvr.confirm({
      nzTitle: "Prompt",
      nzContent:
        "Are you sure you want to delete the selected " +
        this.checkedTableData.length +
        " data?",
      nzOnOk: () => {
        this.delHandle();
      },
    });
  }

  delHandle() {
    let idsArray = [] ;

    this.checkedTableData.map((item) => {
      const id = item.Id ;
      idsArray.push(id);
    });
    let ids = idsArray.join(',');
    ids = ids + ',';

    const params={
      Ids :ids,
      LastEditBy :this.publicSvr.getSettingUserInfo().eeid,
      Func:"SystemSettings-Delete_user_manage"
    }

    this.publicSvr.iwxPost(params,{
      headers:{
       apiID:"ffff-1740459629548-10208193125-1437",
        userKey:this.publicSvr.USER_TN
      }
    },true).then((res:any)=>{
      if(res.IsOK=="1"){
        this.search(true);
        this.msgSvr.success("Success");
      }else{
        this.msgSvr.error(res.Msg);
      }
    }) 

  }

  exportData() {
    this.exportLoading = true;
    this.searchHandle(true);

  }

  // 切換分頁
  change(ret: STChange) {
    if (ret.type === "checkbox") {
      this.checkedTableData = ret.checkbox;
    }
    if (ret.type === 'pi') { // 页码变化
      this.pi = ret.pi
      this.search();
    }
    if (ret.type === 'ps') { // 每頁行數變化
      this.ps = ret.ps;
      this.search(true);
    }
  }

}

