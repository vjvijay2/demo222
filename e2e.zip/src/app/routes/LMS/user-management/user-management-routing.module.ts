import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { MailManageComponent } from './mail-manage/mail-manage.component';

const routes: Routes = [
  {path:'userinfo' ,component:UsermanagementComponent},
  {path: 'mailManage', component: MailManageComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserManagementRoutingModule { }
