import { Component, OnInit, ViewChild,ChangeDetectorRef } from '@angular/core';
import { SFComponent, SFSchema } from "@delon/form";
import { STColumn, STComponent, STChange, STPage, STData, } from "@delon/abc";
import { SettingsService } from '@delon/theme';
import { deepMerge } from "@delon/util";
import { NzMessageService, NzModalService } from "ng-zorro-antd";
import { SharedModule } from "@shared";
import { ActivatedRoute } from "@angular/router";
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { DatePipe } from "@angular/common";
import { I18NService } from '@core/i18n/i18n.service';
import { PublicNetService } from "../../../a_Public_net/Public_net.service";
import { MailDrawerComponent } from '../Drawer/mail-drawer/mail-drawer.component';
import { param } from 'jquery';

@Component({
  selector: 'app-mail-manage',
  templateUrl: './mail-manage.component.html',
  styleUrls: ['./mail-manage.component.less']
})
export class MailManageComponent implements OnInit {
  @ViewChild("sf", { static: false }) sf: SFComponent;
  // @ViewChild('st', { static: false }) private st!: STComponent;
  @ViewChild('st', { static: false }) private st: STComponent;

  constructor(
    private publicSvr: PublicNetService,
    public settings: SettingsService,
    private msgSvr: NzMessageService,
    private shareSvr: SharedModule,
    private modelSvr: NzModalService,
    private router: ActivatedRoute,
    private i18n: I18NService,
    private cdRef:ChangeDetectorRef
  ) { }
title:any = "Mail Manage";
  // 搜索表单
  sfSchema: SFSchema;
  source: any[] = []
  // 表格加載狀態
  loading = false;
  // 當前頁碼
  pi = 1;
  // 每頁數量
  ps = 10;
  // 當前總數量
  total = 0;
  Systemtype:any;
  // table 页码配置
  pages: STPage = {
    show: true,// 显示分页
    front: false, // 关闭前端分页，true是前端分页，false后端控制分页
    showSize: true,
    // pageSizes: [50, 100, 150, 200]
  };
  factoryId:any;
  factoryList=[];
  empid:any
  dept:any
  deptlist=[]
  checkedTableData = [];
  exportLoading: boolean = false;
  delIdx = 0;
  RoleList = [];
  RoleId:any;

  // 表頭
  columns: STColumn[] = [
    { title: "", type: "checkbox", fixed: "left", width: '50px', className: "text-center" },
    { title: "Item", index: "Rn", className: "text-center", width: "80px" },
    { title: "Site", index: "SiteName", className: "text-center", width: "180px" },
    { title: "Mail Role", index: "RoleName", className: "text-center", width: "180px" },
    { title: "Department", index: "DepartmentName", className: "text-center", width: "180px" },
    { title: "Mail TO", index: "MailTo", className: "text-center", width: "300px" },
    { title: "Mail CC", index: "MailCc", className: "text-center", width: "300px" },
   // { title: "Sytem Type", index: "SystemType", className: "text-center", width: "180px" },
    { title: "Add By", index: "AddBy", className: "text-center", width: "180px" },
    { title: "Add Date", index: "AddDate", className: "text-center", width: "180px" },
    { title: "Edit By", index: "EditBy", className: "text-center", width: "180px" },
    { title: "Edit Date", index: "EditDate", className: "text-center", width: "180px" },
  ]

  private submit(i: STData): void {
    this.updateEdit(i, false);
  }

  private updateEdit(i: STData, edit: boolean): void {
    i["edit"] = edit;
  }

  setRowData(index: number, name: string) {

  }

  ngOnInit() {
        this.createForm();
     setTimeout(() => {
    this.search(true);
   }, 100);
  }

  createForm(){
    const _form = [
      { key: "Factory", name: "Site", type: "custom" },
      { key: "Department", name: "Department", type: "custom" },
      { key: "Role", name: "Role", type: "custom" },
    ]
    this.sfSchema = this.publicSvr.jointSchema(_form);
    this.publicSvr.getselectSiteData().subscribe((res: any) => {
      this.factoryList = res;
    })
    this.publicSvr
    .getGuardPassCode("Department")
    .subscribe((res: any) => {
      this.deptlist = [{ label: "All", value: 'All' }, ...res];
    
   });
      this.publicSvr
   .getSPbaseCode(6)
   .subscribe((res: any) => {
     console.log(res)
     this.RoleList = res.filter((item)=>  item.Id === 16 || item.Id ===14)
  });
  }
  
  search(first?: any) {
    this.checkedTableData=[];
    if (first) {
      this.pi = 1;
    }
    this.loading = true;
    this.searchHandle()
  }

  searchHandle(isExport?: any) {
    const params = {
      Role :this.RoleId ? this.RoleId : '',
      Department :this.dept ? this.dept :'',
   AdminEmpId : this.publicSvr.getSettingUserInfo().eeid,
  Site: this.factoryId ? this.factoryId :'',
      StartPage : isExport ? 1 : this.pi,
      PageSize : isExport ? '999999999999' : this.ps,
      Func: "License Manage-Get_mail_info"
    }

    const _params = deepMerge(params, this.sf.value ? this.sf.value : {});
// console.log(_params)
    this.publicSvr.iwxPost(_params, {
      headers: {
        apiID: "ffff-1750759191791-1020912129-0747",
        userKey: this.publicSvr.USER_TN
      }
    }, true).then((res: any) => {
      this.loading = false;
     console.log(res)
      this.exportLoading = false;
      if (res.IsOK == "1") {
        if (isExport) {
          let allData=[];
          if(res.List.length>0){
            let list=res.List;
            list.forEach((item)=>{
              allData.push({
               "Item":item.Rn,
                Site:item.SiteName,
                Department:item.DepartmentName,
                Role:item.RoleName,
                MailTo:item.MailTo,
                MailCC:item.MailCc,
                Addby:item.AddBy,
                AddDate:item.AddDate,
                EditBy:item.EditBy,
                EditDate:item.EditDate
              })
            })
            this.publicSvr.exportHandle(allData,11,"Mail_Info"+new Date().getTime()+".xlsx");
          }else{
            this.msgSvr.error("No Data!")
          }
        } else {
          // this.source = res.List
        //   .map((item) => {
        //     const sitename = this.factoryList.find((value) => value.value == item.Site);
        //     return {
        //         ...item, // Spread the properties of the original item
        //         Site: sitename.label ? sitename.label : '', // Update the Site property
        //     };
        // });
        
          this.total = res.List && res.List.length > 0 ? res.List[0].Rowscount : 0;
         this.source = res.List;
         console.log(this.source)
        console.log(this.source[0].Id); 
        // Corrected source
        // this.source = res.List.map(item => ({
        //   ...item,
        //   Id: item.MailId
        // }));
        }
      } else {
        if (!isExport) {
          this.source = [];
        }
        this.msgSvr.error(res.Msg);
      }
    })
  }
  add() {
    this.openDrawer("Add")
  }

  update() {
    if (this.checkedTableData.length !== 1) {
      this.shareSvr.showMsg("error", this.i18n.fanyi('table.content.edit-data-select'));
      return;
    }
    console.log('Updating row:', this.checkedTableData[0]);
    this.openDrawer("Edit")


  }

  openDrawer(name) {
    console.log(this.checkedTableData)
    this.shareSvr.openDrawer(name, MailDrawerComponent, {
      option: name,
      editData:this.checkedTableData[0],
    }, res => {
      if (res) {
        this.createForm();
        this.search(true);
console.log(res)
      }
      else{
        console.log('Drawer closed without changes');
      }
    });
  }

  delete() {
    if (this.checkedTableData.length == 0) {
      this.shareSvr.showMsg(
        "error",
        this.i18n.fanyi("table.content.edit-data-select")
      );
      return;
    }

    this.delIdx = 0;
    this.shareSvr.modalSvr.confirm({
      nzTitle: "Prompt",
      nzContent:
        "Are you sure you want to delete the selected " +
        this.checkedTableData.length +
        " data?",
      nzOnOk: () => {
        this.delHandle();
      },
    });
  }

  delHandle() {
    let idsArray = [] ;

    this.checkedTableData.map((item) => {
      console.log(item)
      const id = item.Id;
      idsArray.push(id);
    });
    let ids = idsArray.join(',');
    ids = ids + ',';

    const params={
      Ids :ids,
      LastEditBy :this.publicSvr.getSettingUserInfo().eeid,
      Func:"License Manage-Delete_mail_info"
    }

    this.publicSvr.iwxPost(params,{
      headers:{
       apiID:"ffff-1750759121836-1020912129-0744",
        userKey:this.publicSvr.USER_TN
      }
    },true).then((res:any)=>{
      console.log(params)
      if(res.IsOK=="1"){
        this.search(true);
        this.msgSvr.success("Success");
      }else{
        this.msgSvr.error(res.Msg);
      }
    }) 

  }

  exportData() {
    this.exportLoading = true;
    this.searchHandle(true);

  }

  // 切換分頁
  change(ret: STChange) {
    if (ret.type === "checkbox") {
      this.checkedTableData = ret.checkbox;
    }
    if (ret.type === 'pi') { // 页码变化
      this.pi = ret.pi
      this.search();
    }
    if (ret.type === 'ps') { // 每頁行數變化
      this.ps = ret.ps;
      this.search(true);
    }
  }




}
