import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MailManageComponent } from './mail-manage.component';

describe('MailManageComponent', () => {
  let component: MailManageComponent;
  let fixture: ComponentFixture<MailManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MailManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MailManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
