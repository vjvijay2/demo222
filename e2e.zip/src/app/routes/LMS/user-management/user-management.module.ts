import { NgModule } from '@angular/core';
import { SharedModule } from '@shared';
import { UserManagementRoutingModule } from './user-management-routing.module';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { UserManageAddComponent } from './Drawer/user-manage-add/user-manage-add.component';
import { MailManageComponent } from './mail-manage/mail-manage.component';
import { MailDrawerComponent } from './Drawer/mail-drawer/mail-drawer.component';

const COMPONENTS = [];
const COMPONENTS_NOROUNT = [
  UserManageAddComponent,
    MailDrawerComponent

];

@NgModule({
  imports: [
    SharedModule,
    UserManagementRoutingModule
  ],
  declarations: [
    ...COMPONENTS,
    ...COMPONENTS_NOROUNT,
    UsermanagementComponent,
    UserManageAddComponent,
    MailManageComponent,
    MailDrawerComponent
  ],
  entryComponents: COMPONENTS_NOROUNT
})
export class UserManagementModule { }
