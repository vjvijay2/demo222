import { Component, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";
import { SFSchema, SFComponent, SFUISchema } from "@delon/form";
import { NzMessageService, NzDrawerRef } from "ng-zorro-antd";
import { SharedModule } from "@shared";
import { I18NService } from "@core";
import { PublicNetService } from "../../../../a_Public_net/Public_net.service";

@Component({
  selector: 'app-user-manage-add',
  templateUrl: './user-manage-add.component.html',
  styleUrls: ['./user-manage-add.component.less']
})
export class UserManageAddComponent implements OnInit {


  constructor(
    private publicSvr: PublicNetService,
    private msgSvr: NzMessageService,
    private i18n: I18NService,
    private ref: NzDrawerRef,
    private shareSvr: SharedModule,
    private cdr: ChangeDetectorRef

  ) { }

  option: any;
  Site: any
  // canteenareaId: any;
  SiteId: any;
  Empid: any;

  EmpName: any;
  department: any;
  //readerid: any;
  Systemtype: any;
  extno: any
  isadmin: any
  departmentList: any = []
  statusList: []
  SiteList = [];

  editData: any;
  timer: any;



  ngOnInit() {

    // this.publicSvr.getselectSiteData().subscribe((res: any) => {
    //   this.SiteList = res;
    // console.log(this.SiteList);});
    this.getUserInfo();

    this.publicSvr
      .getGuardPassCode("Department")
      .subscribe((res: any) => {
        // console.log(res)
        // console.log(res);
        //   this.departmentList = res;  
        this.departmentList = [{ label: "All", value: 'All' }, ...res];

        //  this.departmentList = res;


      });
    this.publicSvr
      .getSPbaseCode(6)
      .subscribe((res: any) => {
        //  console.log(res)
        this.statusList = res;


      });

    if (this.option === 'Edit') {
      if (this.editData) {
        //  console.log(parseInt(this.editData.DeptId))
        this.Empid = this.editData.EmpId
        this.EmpName = this.editData.EmpName
        this.department = this.editData.DeptId === 'All' ? this.editData.DeptId : parseInt(this.editData.DeptId);
        this.Site = this.editData.SiteId,
          this.isadmin = this.editData.IsAdminId,
          this.extno = this.editData.ExtNo


      }
    }
  }

  getUserInfo() {
    const params = {
      Dept: '',
      EmpId: this.publicSvr.getSettingUserInfo().eeid,
      Site: '',
      StartPage: 1,
      PageSize: 999999999999,
      Func: "SystemSettings-Get_User_manage"
    };

    this.publicSvr.iwxPost(params, {
      headers: {
        apiID: "ffff-1740459507956-10208193125-1431",
        userKey: this.publicSvr.USER_TN
      }
    }, true).then((res: any) => {
      if (res.IsOK == "1") {
        console.log(res);
        const findadminanddri = res.List.some(item => item.IsAdiminName === 'Admin' || item.IsAdiminName === 'DRI');
        // this.SiteList = res.List.map(item => {item.SiteId = item.SiteId ? item.SiteId : '';
        //   item.SiteName = item.SiteName ? item.SiteName : '';
        //       }).filter(item => item.SiteId !== '' && item.SiteName !== '');
        // console.log(this.SiteList);
        res.List.forEach((element) => {
          if (!element) return;
          let _item: any = {};
          _item = {
            label: element.SiteName,
            value: element.SiteId,
            // repairitemgrupid :element.GroupIds,
            // repaircategorygrupid :element.GroupIds2
          };
          this.SiteList.push(_item);
        });
      }
    });
  }









  add() {
    const params = {
      Site: this.Site,
      EmpId: this.Empid,
      EmpName: this.EmpName,
      //   SystemName: this.Systemtype,
      Dept: this.department,
      Isadmin: this.isadmin,
      Extno: this.extno,
      CreateBy: this.publicSvr.getSettingUserInfo().eeid,

    };

    // console.log(params);

    params.Site.forEach(

      item => {

        const params1 = {
          Site: item,
          EmpId: params.EmpId,
          Dept: params.Dept,
          EmpName: params.EmpName,
          Isadmin: params.Isadmin,
          Extno: params.Extno,
          CreateBy: params.CreateBy,

          Func: 'SystemSettings-Insert_User_manage'
        }
        //console.log(params1)
        this.publicSvr
          .iwxPost(
            params1,
            {
              headers: {
                apiID: "ffff-1740459418235-10208193125-1428",
                userKey: this.publicSvr.USER_TN,
              },
            },
            true
          )
          .then((res: any) => {
            if (res.IsOK == "1") {
              this.msgSvr.success("Success");
              this.ref.close(true);
            } else {
              this.msgSvr.error(res.Msg);
            }
          });

      });


  }

  edit() {
    //console.log(this.editData)
    const params = {
      Id: this.editData.Id,
      Site: this.Site,
      EmpId: this.Empid,
      Dept: this.department,
      Extno: this.extno,
      Isadmin: this.isadmin,
      //  Area :this.canteenareaId,
      //  Name :this.canteenNameId,
      //  FloorNo :this.floorId,
      //  Location :this.location,
      //  Status :this.Status,
      //  Guardproid: this.gateAttribute,
      //  Areaid: this.controlArea,
      //   ProjectId: this.projectId,
      //  Remark: this.remark,

      LastEditBy: this.publicSvr.getSettingUserInfo().eeid,
      Func: "SystemSettings-Update_User_manage",
    };
    //console.log(params)
    this.publicSvr
      .iwxPost(
        params,
        {
          headers: {
            apiID: "ffff-1740459576499-10208193125-1434",
            userKey: this.publicSvr.USER_TN,
          },
        },
        true
      )
      .then((res: any) => {
        if (res.IsOK == "1") {
          this.msgSvr.success("Success");
          this.ref.close(true);
        } else {
          this.msgSvr.error(res.Msg);
        }
      });
  }


  getEmpInfo(value) {
    // console.log(value);
    if (value) {
      var vm = this;
      clearTimeout(vm.timer);
      vm.timer = setTimeout(function () {
        vm.publicSvr.getUserBaseInfo(value).then((res: any) => {
          //console.log("專案DRI", res);
          if (res.IsOK == "1") {
            if (res.List && res.List.length > 0) {
              const data = res.List[0];
              //  console.log(data)
              vm.EmpName = data.EmployeeName;
              vm.department = data.Department
              //  vm.projectExtension = data.OfficeTelephone;
              //   vm.projectEmail = data.Emailid;
            } else {
              //  vm.Empid = "";
              //  vm.EmpName = "";
              //  vm.department=''


              //  vm.projectExtension = "";
              //   vm.projectEmail = "";
              vm.msgSvr.error(this.i18n.fanyi("Couldntgetemployeeinformation"));
            }
          } else {
            //  vm.Empid = "";
            //  vm.Empid = "";
            //  vm.department =''


            //  vm.projectExtension = "";
            //  vm.projectEmail = "";
            vm.msgSvr.error(res.Msg);
          }
        });
      }, 1000);
    }
  }

  // checkInputValue(value, name) {
  //   if (value) {
  //     var vm = this;
  //     clearTimeout(vm.timer);
  //     vm.timer = setTimeout(function() {
  //       if (name == "mac") {
  //         // mac地址有兩種：58:E8:76:83:A2:C7 ===>/^[A-F0-9]{2}(:[A-F0-9]{2}){5}$/; 58-E8-76-83-A2-C7  ===>  /^[A-F0-9]{2}(-[A-F0-9]{2}){5}$/
  //         const macReg = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
  //         const res = macReg.test(value);
  //         if (!res) {
  //        //   vm.Mac = "";
  //           vm.msgSvr.error("MAC address format is incorrect.");
  //         }
  //       } else {
  //         // ip地址的校驗:[1-9]?\d===>0-99;1\d{2}==>100-199;2[0-4]\d==>200-249;25[0-5]==>250-255
  //         const ipReg = /^([1-9]?\d|1\d{2}|2[0-4]\d|25[0-5])(\.([1-9]?\d|1\d{2}|2[0-4]\d|25[0-5])){3}$/;
  //         const res = ipReg.test(value);
  //         if (!res) {
  //        //   vm.IP = "";
  //           vm.msgSvr.error("Ip address format is incorrect.");
  //         }
  //       }
  //     }, 500);
  //   }
  // }

  // 取消
  cancel() {
    this.ref.close();
  }
}

