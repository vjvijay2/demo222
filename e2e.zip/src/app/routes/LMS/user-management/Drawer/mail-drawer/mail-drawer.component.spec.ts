import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MailDrawerComponent } from './mail-drawer.component';

describe('MailDrawerComponent', () => {
  let component: MailDrawerComponent;
  let fixture: ComponentFixture<MailDrawerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MailDrawerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MailDrawerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
