import { Component, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";
import { NzMessageService, NzDrawerRef } from "ng-zorro-antd";
import { SharedModule } from "@shared";
import { I18NService } from "@core";
import { PublicNetService } from "../../../../a_Public_net/Public_net.service";

@Component({
  selector: 'app-mail-drawer',
  templateUrl: './mail-drawer.component.html',
  styleUrls: ['./mail-drawer.component.less']
})
export class MailDrawerComponent implements OnInit {
  Role: any;

  constructor(
    private publicSvr: PublicNetService,
    private msgSvr: NzMessageService,
    private i18n: I18NService,
    private ref: NzDrawerRef,
    private shareSvr: SharedModule,
    private cdr: ChangeDetectorRef

  ) { }

  option: any;
  Site: any
  // canteenareaId: any;
  SiteId: any;
  Empid: any;
  MailTo: any;
  MailCC: any;
  EmpName: any;
  department: any;
  Systemtype: any;
  extno: any
  isadmin: any
  departmentList: any = []
  statusList: []
  SiteList = [];

  editData: any;
  timer: any;




  ngOnInit() {
    this.publicSvr.getselectSiteData().subscribe((res: any) => {
      this.SiteList = res;
      console.log(this.SiteList)
    });

    this.publicSvr
      .getGuardPassCode("Department")
      .subscribe((res: any) => {
        console.log(res)
        this.departmentList = [{ label: "All", value: 'All' }, ...res];

        //  this.departmentList = res;


      });
    this.publicSvr
      .getSPbaseCode(6)
      .subscribe((res: any) => {
        console.log(res)
        this.statusList = res.filter(item => item.Id === 16 || item.Id === 14);

      });

    if (this.option === 'Edit') {
      if (this.editData) {
        console.log(this.editData)
        this.Role = this.editData.RoleId
        this.Site = this.editData.Siteid
        this.department = this.editData.DeptId === 'All' ? this.editData.DeptId : parseInt(this.editData.DeptId);
        this.MailCC = this.editData.MailCc,
          this.MailTo = this.editData.MailTo


      }
    }
  }


  add() {
    this.departmentList
    const params = {
      Role: this.Role,
      Mailto: this.MailTo,
      Mailcc: this.MailCC,
      Site: this.Site,
      Department: this.department ? this.department : '',
      AddBy: this.publicSvr.getSettingUserInfo().eeid,
      Func: 'License Manage-Insert_mail_info'
    };
    console.log(params)
    this.publicSvr
      .iwxPost(
        params,
        {
          headers: {
            apiID: "ffff-1750758675480-1020912129-0733",
            userKey: this.publicSvr.USER_TN,
          },
        },
        true
      )
      .then((res: any) => {
        if (res.IsOK == "1") {
          this.msgSvr.success("Success");
          this.ref.close(true);
        } else {
          this.msgSvr.error(res.Msg);
        }
      });

  }



  edit() {
  console.log(this.editData)
    const params = {
      Id: this.editData.Id,
     Site: this.Site,
      Mailto: this.MailTo,
      Mailcc: this.MailCC,
      EditBy: this.publicSvr.getSettingUserInfo().eeid,
      Func: "License Manage-Update_mail_info",
    };
    console.log(params)
    this.publicSvr
      .iwxPost(
        params,
        {
          headers: {
            apiID: "ffff-1750758770779-1020912129-0736",
            userKey: this.publicSvr.USER_TN,
          },
        },
        true
      )
      .then((res: any) => {
        if (res.IsOK == "1") {
          this.msgSvr.success("Success");
          this.ref.close(true);
          console.log(res);
        } else {
          this.msgSvr.error(res.Msg);
        }
      });
  }


  getEmpInfo(value) {
    // console.log(value);
    if (value) {
      var vm = this;
      clearTimeout(vm.timer);
      vm.timer = setTimeout(function () {
        vm.publicSvr.getUserBaseInfo(value).then((res: any) => {
          //console.log("專案DRI", res);
          if (res.IsOK == "1") {
            if (res.List && res.List.length > 0) {
              const data = res.List[0];
              //  console.log(data)
              vm.EmpName = data.EmployeeName;
              vm.department = data.Department
              //  vm.projectExtension = data.OfficeTelephone;
              //   vm.projectEmail = data.Emailid;
            } else {
              //  vm.Empid = "";
              //  vm.EmpName = "";
              //  vm.department=''


              //  vm.projectExtension = "";
              //   vm.projectEmail = "";
              vm.msgSvr.error(this.i18n.fanyi("Couldntgetemployeeinformation"));
            }
          } else {
            //  vm.Empid = "";
            //  vm.Empid = "";
            //  vm.department =''


            //  vm.projectExtension = "";
            //  vm.projectEmail = "";
            vm.msgSvr.error(res.Msg);
          }
        });
      }, 1000);
    }
  }

  // checkInputValue(value, name) {
  //   if (value) {
  //     var vm = this;
  //     clearTimeout(vm.timer);
  //     vm.timer = setTimeout(function() {
  //       if (name == "mac") {
  //         // mac地址有兩種：58:E8:76:83:A2:C7 ===>/^[A-F0-9]{2}(:[A-F0-9]{2}){5}$/; 58-E8-76-83-A2-C7  ===>  /^[A-F0-9]{2}(-[A-F0-9]{2}){5}$/
  //         const macReg = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
  //         const res = macReg.test(value);
  //         if (!res) {
  //        //   vm.Mac = "";
  //           vm.msgSvr.error("MAC address format is incorrect.");
  //         }
  //       } else {
  //         // ip地址的校驗:[1-9]?\d===>0-99;1\d{2}==>100-199;2[0-4]\d==>200-249;25[0-5]==>250-255
  //         const ipReg = /^([1-9]?\d|1\d{2}|2[0-4]\d|25[0-5])(\.([1-9]?\d|1\d{2}|2[0-4]\d|25[0-5])){3}$/;
  //         const res = ipReg.test(value);
  //         if (!res) {
  //        //   vm.IP = "";
  //           vm.msgSvr.error("Ip address format is incorrect.");
  //         }
  //       }
  //     }, 500);
  //   }
  // }

  // 取消
  cancel() {
    this.ref.close();
  }















}
