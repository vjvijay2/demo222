import {
  Component,
  ElementRef,
  Renderer2,
  AfterViewInit,
  ViewChild,
  ViewContainerRef,
  ComponentFactoryResolver,
  OnInit,
  OnDestroy,
  Inject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Input,
  SimpleChange,
} from "@angular/core";
import { DOCUMENT } from "@angular/common";
import {
  Router,
  NavigationEnd,
  RouteConfigLoadStart,
  NavigationError,
  ActivationEnd,
} from "@angular/router";
import { BreakpointObserver, MediaMatcher } from "@angular/cdk/layout";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { NzMessageService } from "ng-zorro-antd";
import { updateHostClass } from "@delon/util";
import { ScrollService, MenuService, MenuIcon } from "@delon/theme";
import { ReuseTabService } from "@delon/abc";
import { environment } from "@env/environment";
import { HttpClient } from "@angular/common/http";
import { ProSettingDrawerComponent } from "../../setting-drawer/setting-drawer.component";
import { BrandService } from "../.././pro.service";
import { isArray } from "util";
import { SharedModule } from "@shared";
import { filter } from "rxjs/operators";
import { PublicNetService } from "../../../../routes/a_Public_net/Public_net.service";

@Component({
  selector: "app-tabs",
  templateUrl: "./tabs.component.html",
  styleUrls: ["./tabs.component.less"],
})
export class TabsComponent implements OnInit {
  // @Input()
  tabList: any[] = [];

  constructor(
    // 路由器控制器
    private route: Router,
    private publicSvr: PublicNetService,
    public pro: BrandService,
  ) {
    this.tabs = []
    route.events
      .pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        let currentUrl = event.url;
        let existIndex = this.tabs.findIndex((item) => item.url === currentUrl);
        // console.log('existIndex',existIndex)
        //  當前tabs不包含url
        if (existIndex == -1) {
          // 查找當前url是否在菜單列表中，匹配名字
          let webUrlIndex = this.menuList.findIndex(
            (item) => item.LinkUrl == currentUrl
          );
          console.log('webUrlIndex',webUrlIndex)
          if (webUrlIndex != -1) {
            this.tabs.push({
              url: event.url,
              name: this.menuList[webUrlIndex].Name,
            });

            let index = this.tabs.findIndex((item) => {
              return item.url == currentUrl;
            });

            this.selectIndex = index;
          }
        } else {
          this.selectIndex = existIndex;
        }
      });
  }

  // 当前选择的tab index
  selectIndex = 0;
  tabs: any[] = [];
  menuList: any[] = []; //菜單列表
  ngOnInit() {
    this.getMenuPageNameUrl();
  }

  closeTab(index): void {
    this.tabs.splice(index, 1);
    this.toDetail(0);
  }
  toDetail(index) {
    if (this.tabs.length > 0) {
      this.route.navigate([this.tabs[index].url]);
    }
  }

  // 獲取所有菜單信息

  async getMenuPageNameUrl() {
    const params = {
      Func: "MainPageControl-GetMenuPageNameUrl",
    };

    // 工具箱接口
    await this.publicSvr.commonAkdPostApi2(params).then((res: any) => {
      if (res.IsOK == "1") {
        this.menuList = res.List;
      } else {
        this.menuList = [];
      }
    });
  }
}
