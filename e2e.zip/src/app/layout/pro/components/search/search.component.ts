import {
  Component,
  ViewChild,
  HostListener,
  ElementRef,
  OnDestroy,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { SettingsService, _HttpClient } from '@delon/theme';
import {PublicNetService} from "../../../../routes/a_Public_net/Public_net.service"
import { NzMessageService } from "ng-zorro-antd";

@Component({
  selector: 'layout-pro-search',
  templateUrl: 'search.component.html',
  // tslint:disable-next-line: no-host-metadata-property
  host: {
    '[class.alain-pro__header-item]': 'true',
    '[class.alain-pro__header-search]': 'true',
    '[class.alain-pro__header-search-show]': 'show',
  },
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LayoutProWidgetSearchComponent implements OnDestroy {
  @ViewChild('ipt', { static: true }) private ipt: ElementRef<any>;
  show = false;
  searchInfo: string;
  search$ = new Subject<string>();
  list: any[] = [];
  // 設置下拉根元素的樣式
  overlayStyle={
    width:"500px"
  }

  constructor(https: _HttpClient, cdr: ChangeDetectorRef,  public settings: SettingsService,private apiSvr:PublicNetService, private msgSvr: NzMessageService,) {
    this.search$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((searchInfo: string) =>
        this.apiSvr.iwxPost({
          SearchKey:searchInfo,
          UserNo:this.apiSvr.getSettingUserInfo().eeid,
          Func:"MainPageControl-GetSearchPageNameUrl"
          },{
          headers:{
            apiID:"ffff-1676257296133-1020819373-0205",
            userKey:this.apiSvr.USER_GQ
          }
        },true)
         ),
      )
      .subscribe((res: any) => {
        console.log('搜索菜單列表',res);
        
        if(res&&res.IsOK=="1"){
          this.list=res.List;
        }else{
          this.list=[];
          // this.msgSvr.error(res.Msg)
        }
        cdr.detectChanges();
      });
  }

  @HostListener('click')
  _click() {
    this.ipt.nativeElement.focus();
    this.show = true;
  }

  ngOnDestroy(): void {
    this.search$.unsubscribe();
  }

}
