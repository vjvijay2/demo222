import { Component, ChangeDetectionStrategy } from '@angular/core';
import { SettingsService } from '@delon/theme';
import { BrandService } from '../../pro.service';

@Component({
  selector: 'layout-pro-logo',
  templateUrl: './logo.component.html',
  styleUrls: ["./logo.component.less"],

  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LayoutProLogoComponent {
  get name() {
    return this.setting.app.name;
  }

  constructor(public pro: BrandService,private setting: SettingsService) {}

  ngOnInit(){
    // console.log('localStorage.getItem("status")',localStorage.getItem("status"))
    
  }

  change(status){
    // console.log('status',status)

  }
}
