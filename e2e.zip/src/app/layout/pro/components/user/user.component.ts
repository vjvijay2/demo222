import { Component, OnInit, Inject, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { SettingsService, _HttpClient } from '@delon/theme';
import { DA_SERVICE_TOKEN, ITokenService } from '@delon/auth';
import { NzMessageService } from "ng-zorro-antd";
import { encrypt } from "@shared/utils/aes";
//wjs
import { CookieService } from 'ngx-cookie-service';
import { ReuseTabService } from "@delon/abc";
import { StartupService } from "@core";
import {security} from '@shared';
import {PublicNetService} from "../../../../routes/a_Public_net/Public_net.service";
import { BrandService } from "../../../../../app/layout/pro/pro.service";

@Component({
  selector: 'layout-pro-user',
  templateUrl: 'user.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LayoutProWidgetUserComponent implements OnInit {
  constructor(
    public settings: SettingsService,
    private router: Router,
    private http: _HttpClient,
    private msgSvr: NzMessageService,
    //wjs
    private settingService: SettingsService,
    private cookieService: CookieService,
    @Inject(ReuseTabService)
    private reuseTabService: ReuseTabService,
    private startupSrv: StartupService,
    public publicSvr:PublicNetService,

    @Inject(DA_SERVICE_TOKEN) private tokenService: ITokenService,
    public pro: BrandService,
  ) { }
  //wjs
  isSwitch = false;
  empnoData = {
    switchAccount: ""
  };

  isVisible = false;
  psdInfo = {
    old: "",
    new: "",
    confirmNewInfo: ""
  };

  isShowSwitchEmp:boolean=true;
  userName:any;
  ngOnInit(): void {
    this.userName=this.publicSvr.getSettingUserInfo().name;
    let origin = window.location.host;
    if(window.location.host == "lms.idpbgind.efoxconn.com" || window.location.host=="lms.idpbgtn.efoxconn.com"|| window.location.host == "10.208.193.124:8000"){
      this.isShowSwitchEmp=false
    
    }
   }

   ngAfterViewInit() {
     setTimeout(()=>{
       this.userName=this.publicSvr.getSettingUserInfo().name;
     },2000)
  }

  
  // 退出登錄
  logout() {
    this.http.post("/logout", {}).subscribe(res => { });
    localStorage.removeItem("fromInfo");
    localStorage.removeItem("toPageInfo");
    localStorage.removeItem("userMenu");
    localStorage.removeItem("isActivate");
    this.tokenService.clear();
    this.settings.setUser({});
    document.cookie = "eeid=";
    document.cookie = "name=";
    this.tokenService.referrer.url="";
    this.router.navigateByUrl(this.tokenService.login_url);
  }
  handleCancel() {
    this.isVisible = false;
    this.psdInfo = {
      old: "",
      new: "",
      confirmNewInfo: ""
    };
  }
  handleOk() {
    if (!this.psdInfo.old || !this.psdInfo.new || !this.psdInfo.confirmNewInfo) {
      this.msgSvr.error("Please complete the information!");
      return;
    };
    if (this.psdInfo.new !== this.psdInfo.confirmNewInfo) {
      this.msgSvr.error("Two passwords are inconsistent!");
      return;
    };

    const param = {
      url: "/user/changePassword",
      data: {
        oldPassword: encrypt(this.psdInfo.old),
        newPassword: encrypt(this.psdInfo.new),
        confirmNewPassword: encrypt(this.psdInfo.confirmNewInfo)
      }
    };

    const body = security.encryptForWeb(JSON.stringify(param.data));

    this.http.post(param.url, body, null, {headers:{"Content-Type": "application/json;charset=UTF-8"}}).subscribe(data => {
      const res = JSON.parse(security.decryptForWeb(data));
      if (res.status === 200) {
        this.msgSvr.success(res.msg);
        this.handleCancel();
        this.tokenService.clear();
        this.router.navigateByUrl(this.tokenService.login_url);
      } else {
        this.msgSvr.error(res.msg);
      }
    });

  }


  // #region social
  loginSuccess(user, data) {
    // 用户信息：包括姓名、头像、邮箱地址
    this.settingService.setUser({userInfo:this.publicSvr.security.encryptForWeb(JSON.stringify(user))});
    // this.settingService.setUser(user);
    // 保存到cookie
    this.cookieService.set("USER_NO", this.publicSvr.security.encryptForWeb(user.eeid));
    this.cookieService.set("USER_NAME", this.publicSvr.security.encryptForWeb(user.name));
    // this.cookieService.set("USER_NO", user.eeid);
    // this.cookieService.set("USER_NAME", user.name);
    this.cookieService.set("IS_FOREIGN", '');
    this.cookieService.set("SESSION_ID", '');
    this.cookieService.set('FIH_TOKEN', '');
    // 解决冲突 
    // 清空路由复用信息
    this.reuseTabService.clear();
    // 设置用户Token信息
    this.tokenService.set({ token: data.JsessionId });
    // 自動刷新
    location.reload();
  }
}
