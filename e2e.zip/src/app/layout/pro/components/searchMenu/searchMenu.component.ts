import { Component, OnInit } from '@angular/core';
import { BrandService } from '../../pro.service';
import { _HttpClient, SettingsService } from '@delon/theme';
import { NzMessageService } from "ng-zorro-antd";
import {security} from '@shared';
import {PublicNetService} from "../../../../routes/a_Public_net/Public_net.service"

@Component({
  selector: 'layout-pro-searchmenu',
  templateUrl: './searchMenu.component.html',
  styleUrls: ['./searchMenu.component.less']
})
export class LayoutProSearchMenuComponent implements OnInit {
  public showContent = false;

  // 搜索内容
  public searchValue = "";

  // 菜单列表
  public tabList: any = {};

  // 菜单访问最多
  public menuLogCountList: any = [];
  public showMenuLogCountList = false;
  public showMenuLogCountLoading = false;

  // 菜单访问最近
  public menuLogLastList: any = [];
  public showMenuLogLastList = false;
  public showMenuLogLastLoading = false;

  public menuBoxHeight = 0;
  public logBoxHeight = 0;
  public listBoxHeight = 0;

  // 用户ID
  public userId = "";

  constructor(
    public pro: BrandService,
    private http: _HttpClient,
    public settings: SettingsService,
    private msgSvc: NzMessageService,
    private apiSvr:PublicNetService
  ) { }

  activeIndex:any;
  isFromMainPage:boolean=false;
  ngOnInit() {
    this.pro.appDelChangeEmitted.subscribe((info) => {
      if(info.isFromMainPage){
        this.isFromMainPage=true;
      }
      // console.log('info',info)
      this.showContent = true;
      this.searchValue = "";

      this.tabList = info;
      this.tabList.children.forEach((tabList,index) => {
        tabList.show = true;
        tabList.children.forEach((categoryList) => {
          categoryList.show = true;
          categoryList.children.forEach((menuList) => {
            menuList.show = true;
            menuList.showText = menuList.text;
          });
        });
        this.showContent = tabList.show;

        if(tabList.id==info.activeMenuId){
          this.activeIndex=index;
        }
      });

      setTimeout(() => {
        this.initClass();
        this.initBoxHeight();
      }, 0);
    });

    this.getMenuLogCountList();
    this.getMenuLogList();

    this.userId = this.apiSvr.getSettingUserInfo().eeid;
  }

  initClass() {
    const tabs = document.getElementsByClassName("tabs");
    // 判斷是否從mainPage頁面跳轉過來
    if(this.isFromMainPage){
      if (tabs.length > 0) {
        tabs[0].children[this.activeIndex].classList.add("tabs-active");
      }

      const lists = document.getElementsByClassName("lists");
      if (lists.length > 0) {
        lists[this.activeIndex].classList.add("displayBlock");
      }

      this.isFromMainPage=false;
    }else{
      if (tabs.length > 0) {
        tabs[0].children[0].classList.add("tabs-active");
      }

      const lists = document.getElementsByClassName("lists");
      if (lists.length > 0) {
        lists[0].classList.add("displayBlock");
      }
    }
    
  }

  initBoxHeight() {
    const main = document.getElementsByClassName("main");
    let mainHeight = 0;
    mainHeight = main[0].clientHeight;

    const closeBox = document.getElementsByClassName("closeBox");
    let closeBoxHeight = 0;
    closeBoxHeight = closeBox[0].clientHeight + 1;

    const menuBox = document.getElementsByClassName("menuBox");
    this.menuBoxHeight = mainHeight - closeBoxHeight;
    menuBox[0].setAttribute('style', 'height:' + this.menuBoxHeight + 'px');

    // const logBox = document.getElementsByClassName("logBox-inner");
    // this.logBoxHeight = mainHeight - closeBoxHeight;
    // logBox[0].setAttribute('style', 'height:' + (this.logBoxHeight - 100) + 'px');

    const searchBox = document.getElementsByClassName("searchBox");
    let searchBoxHeight = 0;
    searchBoxHeight = searchBox[0].clientHeight;

    const tabBox = document.getElementsByClassName("tabBox");
    let tabBoxHeight = 0;
    tabBoxHeight = tabBox[0].clientHeight + 1;

    const listBox = document.getElementsByClassName("listBox");
    this.listBoxHeight = mainHeight - closeBoxHeight - searchBoxHeight - tabBoxHeight - 56;
    listBox[0].setAttribute('style', 'height:' + this.listBoxHeight + 'px');
  }

  siblings(elm, type) {
    const p = elm.parentNode.children;

    for (let i = 0, pl = p.length; i < pl; i++) {
      if (type === 'tab') {
        // p[i].children[0].classList.remove("tabs-active");
        p[i].classList.remove("tabs-active");
      } else if (type === 'list') {
        p[i].classList.remove("displayBlock");
      }

      if (p[i] === elm) {
        if (type === 'tab') {
          // elm.children[0].classList.add("tabs-active");
          elm.classList.add("tabs-active");
        } else if (type === 'list') {
          elm.classList.add("displayBlock");
        }
      }
    }
  }

  closeSearchMenu() {
    this.pro.isShowSearchMenu = false;
    localStorage.removeItem("nemuId");
  }

  changeValue(str) {
    const copyList = this.tabList;

    if (str) {
      copyList.children.forEach((tabList) => {
        tabList.children.forEach((categoryList) => {
          categoryList.children.forEach((menuList) => {
            const strList = menuList.text.match(new RegExp(str, 'ig'));
            if (strList) {
              strList.forEach(element => {
                menuList.showText = menuList.text.replace(element, '<span style="color:#2d78fd;">' + element + '</span>');
              });
              menuList.show = true;
            }

            if (!strList) {
              menuList.show = false;
            }
          });

          categoryList.show = !!categoryList.children.find((item) => {
            return item.show;
          });
        });

        tabList.show = !!tabList.children.find((item) => {
          return item.show;
        });
      });

      this.showContent = !!copyList.children.find((item) => {
        return item.show;
      });
    } else {
      copyList.children.forEach((tabList) => {
        tabList.show = true;
        tabList.children.forEach((categoryList) => {
          categoryList.show = true;
          categoryList.children.forEach((menuList) => {
            menuList.show = true;
            menuList.showText = menuList.text;
          });
        });
        this.showContent = tabList.show;
        this.searchValue = "";
      });
    }

    for (let i = copyList.children.length - 1; i >= 0; i--) {
      if (copyList.children[i].show) {
        setTimeout(() => {
          this.tabChange(copyList.children[i].id);
        }, 0);
      }
    }
  }

  tabChange(id) {
    this.tabList.children.forEach((tabList) => {
      if (id === tabList.id) {
        const tabId = tabList.id;

        const tab = document.getElementById("tab" + tabId);
        this.siblings(tab, "tab");

        const list = document.getElementById("list" + tabId);
        this.siblings(list, "list");
      }
    });

    const listBox = document.getElementById("list" + id);
    if (listBox) {
      listBox.setAttribute('style', 'height:' + this.listBoxHeight + 'px');
    }
  }

  addMenuLog(menuId, menuName) {

    const param = {
      url: "/addMenuLog",
      data: {
        "menuId": menuId,
        "menuName": menuName,
        "empNo": this.userId,
        "systemCode":"NPI"
      }
    };

    const body = security.encryptForWeb(JSON.stringify(param.data));

    this.http.post(param.url, body, null, {headers:{"Content-Type": "application/json;charset=UTF-8"}}).subscribe(data => {
      const res = JSON.parse(security.decryptForWeb(data));
      console.log('res!!',res)
      if (res.status !== 200) {
        if (res.msg) {
          this.msgSvc.error(res.msg);
        }
      }
    });


    // this.http.post("/addMenuLog", {
    //   "menuId": menuId,
    //   "menuName": menuName,
    //   "empNo": this.userId
    // }).subscribe(res => {
    //   if (res.status !== 200) {
    //     if (res.msg) {
    //       this.msgSvc.error(res.msg);
    //     }
    //   }
    // });
  }

  getMenuLogCountList() {
    this.showMenuLogCountLoading = true;

    const param = {
      url: "/menuLog/count/list",
      data: {}
    };

    const body = security.encryptForWeb(JSON.stringify(param.data));
    this.http.post(param.url, body, null, {headers:{"Content-Type": "application/json;charset=UTF-8"}}).subscribe(data => {
      const res = JSON.parse(security.decryptForWeb(data));
      this.showMenuLogCountLoading = false;
      console.log('res!!',res)
      if (res.status === 200) {
        this.menuLogCountList = res.data.rows;

        if (this.menuLogCountList.length > 0) {
          this.showMenuLogCountList = true;
        } else {
          this.showMenuLogCountList = false;
        }
      } else {
        this.showMenuLogCountList = false;

        if (res.msg) {
          this.msgSvc.error(res.msg);
        }
      }
    });

    // this.http.post("/menuLog/count/list", {}).subscribe(res => {
    //   this.showMenuLogCountLoading = false;

    //   if (res.status === 200) {
    //     this.menuLogCountList = res.data.rows;

    //     if (this.menuLogCountList.length > 0) {
    //       this.showMenuLogCountList = true;
    //     } else {
    //       this.showMenuLogCountList = false;
    //     }
    //   } else {
    //     this.showMenuLogCountList = false;

    //     if (res.msg) {
    //       this.msgSvc.error(res.msg);
    //     }
    //   }
    // });
  }

  getMenuLogList() {
    this.showMenuLogLastLoading = true;

    const param = {
      url: "/menuLog/list",
      data: {}
    };
    
    const body = security.encryptForWeb(JSON.stringify(param.data));
    this.http.post(param.url, body, null, {headers:{"Content-Type": "application/json;charset=UTF-8"}}).subscribe(data => {
      const res = JSON.parse(security.decryptForWeb(data));
      this.showMenuLogLastLoading = false;
      console.log('res!!',res)
      if (res.status === 200) {
        this.menuLogLastList = res.data.rows;

        if (this.menuLogLastList.length > 0) {
          this.showMenuLogLastList = true;
        } else {
          this.showMenuLogLastList = false;
        }
      } else {
        this.showMenuLogLastList = false;

        if (res.msg) {
          this.msgSvc.error(res.msg);
        }
      }
    });



  //   this.http.post("/menuLog/list", {}).subscribe(res => {
  //     this.showMenuLogLastLoading = false;

  //     if (res.status === 200) {
  //       this.menuLogLastList = res.data.rows;

  //       if (this.menuLogLastList.length > 0) {
  //         this.showMenuLogLastList = true;
  //       } else {
  //         this.showMenuLogLastList = false;
  //       }
  //     } else {
  //       this.showMenuLogLastList = false;

  //       if (res.msg) {
  //         this.msgSvc.error(res.msg);
  //       }
  //     }
  //   });
  }
}
