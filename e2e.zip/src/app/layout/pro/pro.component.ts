import {
  Component,
  ElementRef,
  Renderer2,
  AfterViewInit,
  ViewChild,
  ViewContainerRef,
  ComponentFactoryResolver,
  OnInit,
  OnDestroy,
  Inject,
  ChangeDetectionStrategy,
  ChangeDetectorRef
} from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router, NavigationEnd, RouteConfigLoadStart, NavigationError } from '@angular/router';
import { BreakpointObserver, MediaMatcher } from '@angular/cdk/layout';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { NzMessageService, } from 'ng-zorro-antd';
import { updateHostClass } from '@delon/util';
import { ScrollService, MenuService, MenuIcon } from '@delon/theme';
import { ReuseTabService } from '@delon/abc';
import { environment } from '@env/environment';
import { HttpClient } from "@angular/common/http";
import { ProSettingDrawerComponent } from './setting-drawer/setting-drawer.component';
import { BrandService } from './pro.service';
import { isArray } from 'util';
import { SharedModule } from "@shared";
import { DA_SERVICE_TOKEN, ITokenService } from '@delon/auth';
import { SettingsService, _HttpClient } from '@delon/theme';
import { PublicNetService } from "../../routes/a_Public_net/Public_net.service";
// import { PlatformLocation } from "@angular/common";
import { serviceUrl } from "../../routes/a_Public_net/Url";



@Component({
  selector: 'layout-pro',
  templateUrl: './pro.component.html',
  // NOTICE: If all pages using OnPush mode, you can turn it on and all `cdr.detectChanges()` codes
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class LayoutProComponent implements OnInit, AfterViewInit, OnDestroy {
  private unsubscribe$ = new Subject<void>();
  private queryCls: string;
  @ViewChild('settingHost', { read: ViewContainerRef, static: false }) private settingHost: ViewContainerRef;

  isFetching = false;
  isError = false;

  get isMobile() {
    return this.pro.isMobile;
  }

  get getLayoutStyle() {
    const { isMobile, fixSiderbar, collapsed, menu, width, widthInCollapsed } = this.pro;
    if (fixSiderbar && menu !== 'top' && !isMobile) {
      return {
        paddingLeft: (collapsed ? widthInCollapsed : width) + 'px',
      };
    }
    return null;
  }

  get getContentStyle() {
    const { fixedHeader, headerHeight } = this.pro;
    return {
      margin: '24px 16px 0',
      // 'padding-top': (fixedHeader ? headerHeight : 0) + 'px',//
    };
  }

  private get body(): HTMLElement {
    return this.doc.body;
  }

  constructor(
    bm: BreakpointObserver,
    mediaMatcher: MediaMatcher,
    router: Router,
    private msg: NzMessageService,
    scroll: ScrollService,
    reuseTabSrv: ReuseTabService,
    private resolver: ComponentFactoryResolver,
    private el: ElementRef,
    private renderer: Renderer2,
    public pro: BrandService,
    private menuService: MenuService,
    private http: _HttpClient,
    private shareSvr: SharedModule,
    private publicSvr: PublicNetService,
    private route: Router,
    // public locations: PlatformLocation,
    @Inject(DOCUMENT) private doc: any,
  ) // private cdr: ChangeDetectorRef
  {
    // scroll to top in change page
    router.events.pipe(takeUntil(this.unsubscribe$)).subscribe(evt => {
      if (!this.isFetching && evt instanceof RouteConfigLoadStart) {
        this.isFetching = true;
        scroll.scrollToTop();
      }
      if (evt instanceof NavigationError) {
        this.isFetching = false;
        // this.msg.error(`无法加载${evt.url}路由`, { nzDuration: 1000 * 3 });
        // router.navigateByUrl("/exception/404") 
        // 请尝试刷新缓存获取最新系统内容
        this.shareSvr.modalSvr.confirm({
          nzTitle: "Sorry, the system timed out!",//`无法加载${evt.url}路由`
          nzContent: 'Try flushing the cache to get the latest system content?Clicking OK will refresh the cache.',//尝试刷新缓存获取最新系统内容?点击OK将刷新缓存
          nzOnOk: () => { location.reload(); this.isError = true; }
        });

        // 如果3秒钟后没有点击OK的话，自动刷新
        setTimeout(() => {
          if (!this.isError) {
            location.reload();
          }
        }, 3000)
        // 请尝试刷新缓存获取最新系统内容
        return;
      }
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      this.isFetching = false;
      // If have already cached router, should be don't need scroll to top
      if (!reuseTabSrv.exists(evt.url)) {
        scroll.scrollToTop();
      }
    });

    // media
    const query = {
      'screen-xs': '(max-width: 575px)',
      'screen-sm': '(min-width: 576px) and (max-width: 767px)',
      'screen-md': '(min-width: 768px) and (max-width: 991px)',
      'screen-lg': '(min-width: 992px) and (max-width: 1199px)',
      'screen-xl': '(min-width: 1200px)',
    };
    bm.observe([
      '(min-width: 1200px)',
      '(min-width: 992px) and (max-width: 1199px)',
      '(min-width: 768px) and (max-width: 991px)',
      '(min-width: 576px) and (max-width: 767px)',
      '(max-width: 575px)',
    ]).subscribe(() => {
      this.queryCls = Object.keys(query).find(key => mediaMatcher.matchMedia(query[key]).matches);
      this.setClass();
    });
  }

  private setClass() {
    const { body, renderer, queryCls, pro } = this;
    updateHostClass(body, renderer, {
      ['color-weak']: pro.layout.colorWeak,
      [`layout-fixed`]: pro.layout.fixed,
      [`aside-collapsed`]: pro.collapsed,
      ['alain-pro']: true,
      [queryCls]: true,
      [`alain-pro__content-${pro.layout.contentWidth}`]: true,
      [`alain-pro__fixed`]: pro.layout.fixedHeader,
      [`alain-pro__wide`]: pro.isFixed,
      [`alain-pro__dark`]: pro.theme === 'dark',
      [`alain-pro__light`]: pro.theme === 'light',
    });
  }

  ngAfterViewInit(): void {
  }

  ngOnInit() {
    const { pro, unsubscribe$ } = this;
    pro.notify.pipe(takeUntil(unsubscribe$)).subscribe(() => {
      this.setClass();
    });

    // 获取用户对应菜单
    this.getSystemMenu();
  }
  // getSystemMenu() {
  //   const group = [
  //     {
  //       text: "主導航",
  //       group: true,
  //       children: []
  //     }
  //   ];
  //   this.http.post(serviceUrl+"/menuFms", {}).subscribe(res => {
  //     if(res && isArray(res)){
  //       group[0].children = this.arrayToTree(res);
  //       this.menuService.add(group);
  //     }else{
  //       this.msg.error("您暫無可查看的菜單，請聯繫管理員開通！", { nzDuration: 1000 * 3 });
  //     }
  //   });
  // }

  // getToMenuData(data,menuId){
  //   const toMenuData = data.filter(item => {
  //       return item.id == menuId;
  //   });
  //   if(toMenuData.length==0){
  //     data.forEach((item)=>{
  //       if(item.children.length!=0){
  //         const list=item.children;
  //         this.getToMenuData(list,menuId)
  //       }
  //     })

  //   }else{
  //     const menuData=toMenuData[0];
  //     this.getPage(menuData)
  //   }
  // }
  getSystemMenu() {
    const group = [
      {
        text: "主導航",
        group: true,
        children: [],
      },
    ];

    const params = {
      Func: "Permission management-GetUserPermitModuleBySystem",
      SystemId: 30373,
      EmpNo: this.publicSvr.getSettingUserINfo().eeid,
    };

    const param = true
      ? this.publicSvr.dealPostParamsEncrypt(params)
      : this.publicSvr.dealPostParams(params);

    new Promise((resolve, reject) => {
      this.http
        .post(
          'https://microservice.abgind.foxconn.com/india/gateway',
          param,
          null,
          {
            headers: {
              apiID: "ffff-1687574205823-1020819373-1797",
              userKey: this.publicSvr.USER_APPLIATION_WEB,
            },
          }
        )
        .subscribe(
          (data) => {
            let res = true
              ? JSON.parse(this.publicSvr.security.decrypt(data.r, this.publicSvr.iwxKInfo))
              : data;
            resolve(res);
          },
          (err) => {
            reject(err);
          }
        );
    })
      .then((res: any) => {

        console.log("===== MENU API =====");
        console.log("Full Response:", res);
        console.log("IsOK:", res.IsOK);
        console.log("List:", res.List);

        if (res.IsOK == "1") {

          const menuTree = this.arrayToTree(res.List);

          console.log("Menu Tree:", menuTree);

          group[0].children = menuTree;

          console.log("Final Menu:", group);

          this.menuService.add(group);

        } else {
          this.msg.error(
            "您暫無可查看的菜單，請聯繫管理員開通！",
            {
              nzDuration: 1000 * 3,
            }
          );
        }
      })
      .catch(err => {
        console.error("Menu API Error:", err);
      });
  }


  getToMenuData(data, menuId) {
    const toMenuData = data.filter((item) => {
      return item.id == menuId;
    });
    if (toMenuData.length == 0) {
      data.forEach((item) => {
        if (item.children.length != 0) {
          const list = item.children;
          this.getToMenuData(list, menuId);
        }
      });
    } else {
      const menuData = toMenuData[0];
      this.getPage(menuData);
      // console.log('menuData',menuData)
    }
  }
  getPage(data) {
    if (data.children.length > 0) {
      const list = data.children[0];
      this.getPage(list);
    } else {
      const toPage = data.link;
      this.route.navigateByUrl(toPage);
      localStorage.removeItem("fromInfo");
      localStorage.removeItem("toPageInfo");
      localStorage.removeItem("userMenu");
      localStorage.removeItem("userMenuId");
    }
  }
  arrayToTree(list, ModuleParentId = -1) {

    if (!list || !Array.isArray(list)) {
      console.error("Menu list invalid:", list);
      return [];
    }

    return list
      .filter(
        item => Number(item.ModuleParentId) === Number(ModuleParentId)
      )
      .map(item => {

        let icon = item.Icon
          ? ({
            type: "icon",
            value: item.Icon.split("|")[0],
            theme: item.Icon.split("|")[1] || "outline",
          } as MenuIcon)
          : null;

        const ModuleName =
          Number(item.ModuleParentId) === -1
            ? "NPI Proposal"
            : item.ModuleName;

        return {
          text: ModuleName,
          icon: icon,
          link: item.ModuleUrl,
          parentId: item.ModuleParentId,
          children: this.arrayToTree(list, item.ModuleId),
          id: item.ModuleId,
          show: true,
        };
      });
  }
  ngOnDestroy() {
    const { unsubscribe$, body, pro } = this;
    unsubscribe$.next();
    unsubscribe$.complete();
    body.classList.remove(
      `alain-pro__content-${pro.layout.contentWidth}`,
      `alain-pro__fixed`,
      `alain-pro__wide`,
      `alain-pro__dark`,
      `alain-pro__light`,
    );
  }
}
