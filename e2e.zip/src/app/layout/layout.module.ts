import { NgModule } from '@angular/core';
import { LayoutModule as CDKLayoutModule } from '@angular/cdk/layout';
import { SharedModule } from '@shared/shared.module';

import { PRO_ENTRYCOMPONENTS, PRO_COMPONENTS } from './pro/index';
import { CookieService } from 'ngx-cookie-service';
// passport
import { LayoutPassportComponent } from './passport/passport.component';
import { TabsComponent } from './pro/components/tabs/tabs.component';
const PASSPORT = [LayoutPassportComponent];


@NgModule({
  imports: [SharedModule, CDKLayoutModule],
  entryComponents: PRO_ENTRYCOMPONENTS,
  declarations: [...PRO_COMPONENTS, ...PASSPORT, TabsComponent],
  exports: [...PRO_COMPONENTS, ...PASSPORT],
  providers: [CookieService],
})
export class LayoutModule { }
