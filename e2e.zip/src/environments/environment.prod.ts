// 正式服务器
// http://ipocket.idpbgtn.efoxconn.com:8080===>2025-05-11http升級為https:https://ipocket.idpbgtn.efoxconn.com:4443
export let serverUrl:string ="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg";//正式;
((doc)=>{
  urlManage();
})(document)

function urlManage(){
 
  if (window.location.host == "lms.idpbgind.efoxconn.com" || window.location.host == "10.208.193.124:8000") {
    serverUrl="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg"

  }else if(window.location.host == "lms.idpbgtn.efoxconn.com"){
    serverUrl="https://ipocket.idpbgtn.efoxconn.com:4443/springboot-indiaEisp-pg"

  } else {
    //serverUrl ="http://10.208.193.152:8080"
    serverUrl="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg"
  }
}

// 正式打包時接口前綴配置
// 正式服務器 2022-7-12:  ipocket.idpbgtn.efoxconn.com替換eisp.idpbgtn.efoxconn.com
export const environment = {
  SERVER_URL:`${serverUrl}`,
  // SERVER_URL: `https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg`,//正式
  // SERVER_URL: `http://10.172.114.93:8099/springboot-indiaEisp-pg`,//測試--切換賬號
  // SERVER_URL: `http://10.208.193.152:8080/springboot-indiaEisp-pg`,  //測試
  production: true,
  useHash: true,
  hmr: false,
};
