// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

// 正式服务器
// http://ipocket.idpbgtn.efoxconn.com:8080===>2025-05-11http升級為https:https://ipocket.idpbgtn.efoxconn.com:4443

// 测试服务器
// http://10.208.193.152:8080

export let serverUrl:string ="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg";//正式;
((doc)=>{
  urlManage();
})(document)

function urlManage(){
 
  if (window.location.host == "lms.idpbgind.efoxconn.com" || window.location.host == "10.208.193.124:8000") {
    serverUrl="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg"

  }else if(window.location.host == "lms.idpbgtn.efoxconn.com"){
    serverUrl="https://ipocket.idpbgtn.efoxconn.com:4443/springboot-indiaEisp-pg"

  } else {
    //serverUrl ="http://10.208.193.152:8080"
    serverUrl="https://ipocket.idpbgind.efoxconn.com:4443/springboot-indiaEisp-pg"
  }
}

// 正式服務器 2022-7-12:  ipocket.idpbgtn.efoxconn.com替換eisp.idpbgtn.efoxconn.com
export const environment = {
  SERVER_URL:`${serverUrl}`,
  // SERVER_URL: `https://ipocket.idpbgtn.efoxconn.com:4443/springboot-indiaEisp-pg`,//正式
  // SERVER_URL: `http://10.172.114.93:8099/springboot-indiaEisp-pg`,  //測試--切換賬號
  // SERVER_URL: `http://10.208.193.152:8080/springboot-indiaEisp-pg`,  //測試
  production: false,
  useHash: true,
  hmr: false,
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

