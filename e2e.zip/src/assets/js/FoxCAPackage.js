﻿///NO:ZIT1009004
///Date:2010.10.07
///Author: Shi W.H.
///Function:增加MLB SignIn函数

/// <summary>
/// 用於保存所選證書信息
/// </summary>


function SignIn() {
    var Signer;
    var info;
    if (typeof (Signer2) != "object") {
        alert(typeof (Signer2));

        try {
            Signer = Signer2;
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用vbscript
                Signer = SignObject();
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                //Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }

        }
    }
    else {
        try {
            Signer = SignObject();
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用javascript
                Signer = Signer2;
                info = Signer.SignIn();
                //alert(info);
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                //Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    if (info == null) {
        window.location = "../FormsForProcessTotalInfo.aspx";
        return;
    }
    else {
        var o = new Object();
        var datas = info.split(',');
        for (var i = 0; i < datas.length - 1; i++) {
            if (datas[i].indexOf('CN=') >= 0) { o.CertName = datas[i].substring(datas[i].indexOf('CN=') + 3); }
            if (datas[i].indexOf('E=') >= 0) o.Email = datas[i].substring(datas[i].indexOf('E=') + 2);
            if (datas[i].indexOf('SN=') >= 0) { o.SerialNumber = datas[i].substring(datas[i].indexOf('SN=') + 3); }
            if (datas[i].indexOf('EffectiveDate=') >= 0) o.EffectiveDate = datas[i].substring(datas[i].indexOf('EffectiveDate=') + 14);
        }

        if (info.CertName != '') {  // 簽章登陸成功處理, 紀錄session 
            send(o.CertName);
        }
        else {
            //失敗處理
            //alert("gds");
            window.location = "../FormsForProcessTotalInfo.aspx";
            send("false");
        }
    }
}


function SignInMLB() {

    var Signer;
    var info;
    if (typeof (Signer2) != "object") {
        // alert(typeof(Signer2));
        try {
            Signer = Signer2;
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用vbscript
                Signer = SignObject();
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                // Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    else {
        try {
            Signer = SignObject();
            info = Signer.SignIn();

        }
        catch (e) {
            try {
                // 發生例外改用javascript
                Signer = Signer2;
                info = Signer.SignIn();//modify lws 20200303           
                //alert(info);
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                // Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignSuccessfulList();
            }
        }
    }
    if (info == null) {
        window.location = "../FormsForProcessTotalInfo.aspx";
        return;
    }
    else {
        var o = new Object();
        var datas = info.split(',');
        for (var i = 0; i < datas.length - 1; i++) {
            if (datas[i].indexOf('CN=') >= 0) { o.CertName = datas[i].substring(datas[i].indexOf('CN=') + 3); }
            if (datas[i].indexOf('E=') >= 0) o.Email = datas[i].substring(datas[i].indexOf('E=') + 2);
            if (datas[i].indexOf('SN=') >= 0) { o.SerialNumber = datas[i].substring(datas[i].indexOf('SN=') + 3); }
            if (datas[i].indexOf('EffectiveDate=') >= 0) o.EffectiveDate = datas[i].substring(datas[i].indexOf('EffectiveDate=') + 14);
        }

        if (info.CertName != '') {  // 簽章登陸成功處理, 紀錄session 
            sendMLB(o.CertName);
        }
        else {
            //失敗處理
            //alert("gds");
            window.location = "../FormsForProcessTotalInfo.aspx";
            sendMLB("false");
        }
    }
}


function SignInDetail() {
    var Signer;
    var info;
    if (typeof (Signer2) != "object") {
        alert(typeof (Signer2));

        try {
            Signer = Signer2;
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用vbscript
                Signer = SignObject();
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                // Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    else {
        try {
            Signer = SignObject();
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用javascript
                Signer = Signer2;
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                //Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    if (info == null) {
        window.close();
        return;
    }
    else {
        var o = new Object();
        var datas = info.split(',');
        for (var i = 0; i < datas.length - 1; i++) {
            if (datas[i].indexOf('CN=') >= 0) { o.CertName = datas[i].substring(datas[i].indexOf('CN=') + 3); }
            if (datas[i].indexOf('E=') >= 0) o.Email = datas[i].substring(datas[i].indexOf('E=') + 2);
            if (datas[i].indexOf('SN=') >= 0) { o.SerialNumber = datas[i].substring(datas[i].indexOf('SN=') + 3); }
            if (datas[i].indexOf('EffectiveDate=') >= 0) o.EffectiveDate = datas[i].substring(datas[i].indexOf('EffectiveDate=') + 14);
        }

        if (info.CertName != '') {  // 簽章登陸成功處理, 紀錄session 
            send(o.CertName);
        }
        else {
            //失敗處理
            //alert("gds");
            window.close();
            send("false");

        }
    }
}
function SignInEGR() {
    var Signer;
    var info;
    if (typeof (Signer2) != "object") {
        //alert(typeof(Signer2));

        try {
            Signer = Signer2;
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用vbscript
                Signer = SignObject();
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                //Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    else {
        try {
            Signer = SignObject();
            info = Signer.SignIn();
        }
        catch (e) {
            try {
                // 發生例外改用javascript
                Signer = Signer2;
                info = Signer.SignIn();
            }
            catch (e) {//谷歌瀏覽器使用 20200305
                // Signer = SignObject();
                Signer = Signer2;
                info = Signer.SignIn();
            }
        }
    }
    if (info == null) {
        window.close();
        return;
    }
    else {
        var o = new Object();
        var datas = info.split(',');
        for (var i = 0; i < datas.length - 1; i++) {
            if (datas[i].indexOf('CN=') >= 0) { o.CertName = datas[i].substring(datas[i].indexOf('CN=') + 3); }
            if (datas[i].indexOf('E=') >= 0) o.Email = datas[i].substring(datas[i].indexOf('E=') + 2);
            if (datas[i].indexOf('SN=') >= 0) { o.SerialNumber = datas[i].substring(datas[i].indexOf('SN=') + 3); }
            if (datas[i].indexOf('EffectiveDate=') >= 0) o.EffectiveDate = datas[i].substring(datas[i].indexOf('EffectiveDate=') + 14);
        }

        if (info.CertName != '') {  // 簽章登陸成功處理, 紀錄session 
            sendEGR(o.CertName);
        }
        else {
            //失敗處理
            //alert("gds");
            window.close();
            sendEGR("false");

        }
    }
}
function updatePage() {
    //     alert("Server is done!");
}


function ajaxscallback(fn, obj1, typeid, factor, callback) {
    ajaxscallbackurl("AjaxPage.aspx", fn, obj1, typeid, factor, callback);
}
function ajaxs(fn, obj1, typeid, factor) {
    ajaxscallback(fn, obj1, typeid, factor, function () { });
}

function test(fileIds, fields, cerName, SignSuccessfulList, SignErrorList, LastErrorMsg) {
    ajaxs(function (data, obj1) {

    }, "", "1", "fileIds=" + escape(fileIds) + "&fields=" + escape(fields) + "&cerName=" + escape(cerName) + "&SignSuccessfulList=" + escape(SignSuccessfulList) + "&SignErrorList=" + escape(SignErrorList) + "&LastErrorMsg=" + escape(LastErrorMsg));
}

function GoSign2(fileIds, fields, cerName, url, obj_para) {

    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    // var fields = fields.replace(/Sign1/g, "Sign7"); //"Sign3,Sign3"; //delete by wj 20131217
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");
    var successfulList = Signer2.SignSuccessfulList;
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;
    var idlist = successfulList.split(',');
    // idlist[2] is 
    // alert(successfulList);
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //alert(result);
        //  alert('電子簽章成功!')
    }
    else {
        alert(errMsg);
        return;
    }
    //alert(idlist[2]);  
    document.getElementById("txt_Result").value = result;
    if (document.getElementById("img_VerifySubmit") != null) {
        document.getElementById("img_VerifySubmit").click();
    }
    //     foxca_after(url,obj_para,idlist[0]);
}


function GoSignDetail(fileIds, fields, cerName, url, obj_para) {

    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    //var fields = fields.replace(/Sign1/g, "Sign7"); //"Sign3,Sign3";  //delete by wj 20131217
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");

    var successfulList = Signer2.SignSuccessfulList;
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;
    var idlist = successfulList.split(',');
    // idlist[2] is 
    // alert(successfulList);
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //alert(result);
        //alert('電子簽章成功!')
    }
    else {
        alert(errMsg);
        return;
    }
    //alert(idlist[2]);
    document.getElementById("txt_Result").value = result;
    if (document.getElementById("img_VerifySubmit") != null) {
        document.getElementById("img_VerifySubmit").click();
    }
    //     foxca_after(url,obj_para,idlist[0]);
}
function GoSignEGR(fileIds, fields, cerName, url, obj_para) {

    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    var fields = fields.replace(/Sign1/g, "Sign1"); //"Sign3,Sign3";
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");
    var successfulList = Signer2.SignSuccessfulList;
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;
    var idlist = successfulList.split(',');
    // idlist[2] is 
    // alert(successfulList);
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //   alert(successfulList);//27
        //sting ScriptDataGrid1=DataGrid1.ClientID;
        //Page.RegisterStartupScript(initElement,"<script lang=...>var datagrid1="+ScriptDataGrid1+";</script>");

        //document.getElementById("txt_NewPDFID").value = idlist[2];
        // alert(document.getElementById("txt_NewPDFID").value);//27
    }
    else {

        //  alert(fileIds);//27
        //document.getElementById("txt_NewPDFID").value = fileIds;

    }
    document.getElementById("txt_Result").value = result;
    document.getElementById("imb_Submit").click();
}


export function GoSignEGR_New(fileIds, fields, cerName, url, obj_para, gv_clientID) {

    //document.getElementById("txt_PdfList").value = fileIds;

    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    var fields = fields.replace(/Sign1/g, "Sign1"); //"Sign3,Sign3";
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");

    var successfulList = Signer2.SignSuccessfulList;
    //document.getElementById("txt_ErrorList").value = (Signer2.SignErrorList == null || Signer2.SignErrorList == "undefined" ? "" : Signer2.SignErrorList);
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;
    var idlistss = successfulList.split(';');
    var idlist = "";
    var idOldelist = "";
    // alert( idlistss[0] + "&&&& " + idlistss[1]);

    for (var i = 0; i < idlistss.length - 1; i++) {

        var idlists = idlistss[i].split(',');
        idlist = idlist + idlists[2] + ",";
        idOldelist = idOldelist + idlists[0] + ",";
        // alert(idlist);
    }
    idlist.replace(undefined, "");
    idOldelist.replace(undefined, "");
    //alert(idlist);
    // idlist[2] is 
    // alert(successfulList);
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //alert(successfulList);
        //document.getElementById("txt_NewPDFID").value = idlist; //.substring(0,idlist[2].length-1);
        //alert(document.getElementById("txt_NewPDFID").value);
        //alert(document.getElementById(gv_clientID).value);
        //document.getElementById("txt_OldePDFID").value = idOldelist;
    }
    else {
        alert(result);
        return;
        //alert(fileIds);
        //document.getElementById("txt_NewPDFID").value = idlist;
        //document.getElementById("txt_OldePDFID").value = idOldelist;
        //document.getElementById("txt_NewPDFID").value = fileIds;
        // document.getElementById("txt_OldePDFID").value = fileIds;

    }
    document.getElementById("txt_Result").value = result;
    if (document.getElementById("img_VerifySubmit") != null) {
        document.getElementById("img_VerifySubmit").click();
    }
    //document.getElementById("txt_Result").value = result;

    //document.getElementById("txt_errMsg").value = errMsg;

    //document.getElementById("txt_errMsg").value = "NewPDFID:" + document.getElementById("txt_NewPDFID").value + " OldePDFID:" + document.getElementById("txt_OldePDFID").value + " " + errMsg;

    //document.getElementById("imb_Submit").click();
    if (result == true) {
        return result
    } else {
        return errMsg
    }

}

function send(CertName) {
    var url = "../../../../ProtectFoxCA/FoxcaSetSession.aspx?CertName=" + encodeURIComponent(CertName);
    var content = ""
    http_request = false;
    if (window.XMLHttpRequest) {
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    else {
        http_request = new ActiveXObject("MSXML2.XMLHTTP.3.0");
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    http_request.onreadystatechange = updatePage;
    http_request.open("post", url, true);
    http_request.send(content);
    //alert(CertName);  
}


function sendMLB(CertName) {
    var url = "../../../ProtectFoxCA/FoxcaSetSession.aspx?CertName=" + encodeURIComponent(CertName);
    var content = "";
    http_request = false;
    if (window.XMLHttpRequest) {
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    else {
        http_request = new ActiveXObject("MSXML2.XMLHTTP.3.0");
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    http_request.onreadystatechange = updatePage;
    http_request.open("post", url, true);
    http_request.send(content);
    //alert(CertName);  
}
function sendEGR(CertName) {
    var url = "../../../../ProtectFoxCA/FoxcaSetSession.aspx?CertName=" + encodeURIComponent(CertName);
    var content = ""
    http_request = false;
    if (window.XMLHttpRequest) {
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    else {
        http_request = new ActiveXObject("MSXML2.XMLHTTP.3.0");
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    http_request.onreadystatechange = updatePage;
    http_request.open("post", url, true);
    http_request.send(content);
}

function foxca_after(url, strPDFID, strNewPDFID) {
    //alert("1");   

    var url = url; //"&strPDFID="+encodeURIComponent(strPDFID);//+"&strNewPDFID=" + encodeURIComponent(strNewPDFID);
    var content = ""
    http_request = false;
    if (window.XMLHttpRequest) {
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType("text/xml");
        }
    }
    http_request.onreadystatechange = updatePage;
    http_request.open("post", url, true);
    http_request.send(content);
    // alert("2");
}

function getBrowserVersion() {
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    if (window.ActiveXObject)
        Sys.ie = ua.match(/msie ([\d.]+)/)[1]
    else if (document.getBoxObjectFor)
        Sys.firefox = ua.match(/firefox\/([\d.]+)/)[1]
    else if (window.MessageEvent && !document.getBoxObjectFor)
        Sys.chrome = ua.match(/chrome\/([\d.]+)/)[1]
    else if (window.opera)
        Sys.opera = ua.match(/opera.([\d.]+)/)[1]
    else if (window.openDatabase)
        Sys.safari = ua.match(/version\/([\d.]+)/)[1];

    if (Sys.ie) document.write('IE: ' + Sys.ie);
    if (Sys.firefox) document.write('Firefox: ' + Sys.firefox);
    if (Sys.chrome) document.write('Chrome: ' + Sys.chrome);
    if (Sys.opera) document.write('Opera: ' + Sys.opera);
    if (Sys.safari) document.write('Safari: ' + Sys.safari);
}

function GoSign2ForMLB(fileIds, fields, cerName, url, obj_para, strPosition) {
    document.getElementById("txt_PdfList").value = fileIds;

    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    //var fields = fields.replace(/Sign1/g, strPosition); //"Sign3,Sign3"; //delete by wj 20131217
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");
    var successfulList = Signer2.SignSuccessfulList;
    document.getElementById("txt_ErrorList").value = (Signer2.SignErrorList == null || Signer2.SignErrorList == "undefined" ? "" : Signer2.SignErrorList);
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;

    test(fileIds, fields, cerName, successfulList, document.getElementById("txt_ErrorList").value, errMsg);

    var idlistss = successfulList.split(';');
    var idlist = "";
    var idOldelist = "";
    for (var i = 0; i < idlistss.length - 1; i++) {
        var idlists = idlistss[i].split(',');
        idlist = idlist + idlists[2] + ",";
        idOldelist = idOldelist + idlists[0] + ",";
    }
    idlist.replace(undefined, "");
    idOldelist.replace(undefined, "");
    url = url + "&SignResult=" + result
    if (result == 'true') {
        document.getElementById("txt_NewPDFID").value = idlist;
        document.getElementById("txt_OldePDFID").value = idOldelist;
    }
    else {
        document.getElementById("txt_NewPDFID").value = idlist;
        document.getElementById("txt_OldePDFID").value = idOldelist;

    }
    document.getElementById("txt_Result").value = result;
    document.getElementById("txt_errMsg").value = errMsg;

    /*
    var idlist = successfulList.split(',');
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //alert(result);
    }
    else {
        //alert(errMsg);
    }
    document.getElementById("txt_Result").value = result;
    if (result == "true")
        document.getElementById("txt_NewPDFID").value = successfulList;
    else
        document.getElementById("txt_NewPDFID").value = fileIds; */
    document.getElementById("imb_Submit").click();

}

function GoSignDetailForMLB(fileIds, fields, cerName, url, obj_para, Position) {
    var fileIds = fileIds; //"6EDB4CED-40E1-4F95-A8F5-7BD455618B78," +"220A2479-451D-43F0-8036-87D1682C4DA1";
    //var fields = fields.replace(/Sign1/g, Position); //"Sign3,Sign3";  //delete by wj 20131217
    var cerName = cerName;
    var url = url;
    var result = Signer2.SignByName2(fileIds, fields, cerName, "FOXCONN CA");
    var successfulList = Signer2.SignSuccessfulList;
    //var errorList = Signer2.SignErrorList;
    var errMsg = Signer2.LastErrorMsg;
    var idlist = successfulList.split(',');
    // idlist[2] is 
    // alert(successfulList);
    url = url + "&SignResult=" + result
    if (result == 'true') {
        //alert(result);
        //  alert('電子簽章成功!')
    }
    else {
        //alert(errMsg);
    }
    //alert(idlist[2]);
    document.getElementById("txt_Result").value = result;
    if (result == "true")
        document.getElementById("txt_NewPDFID").value = idlist[2];
    else
        document.getElementById("txt_NewPDFID").value = fileIds;
    document.getElementById("imb_SubmitDetail").click();
    //     foxca_after(url,obj_para,idlist[0]);
} 